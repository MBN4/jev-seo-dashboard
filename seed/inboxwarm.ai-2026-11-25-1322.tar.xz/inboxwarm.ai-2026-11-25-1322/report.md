# Jev SEO audit: inboxwarm.ai

Audited 2026-11-25T13:23:43+00:00 · 464 URLs crawled · 461 HTML pages · 0 Jev judgments · Jev cost $0.0000

**Overall score: 88/100 (grade B)**

> **Partial audit:** Jev judgments unavailable, so content quality was not assessed; PageSpeed Insights unavailable, so performance used crawl timings only. The overall score covers only the areas that were assessed.

<img src="charts/gauge.png" alt="Overall score" width="220">

| Area | Score | Weight | How it is scored |
|---|---:|---:|---|
| Crawl and indexing | 68 | 20 | Rules only |
| On-page | 94 | 15 | Rules only |
| Content quality | n/a | 20 | Not assessed: Jev judgments unavailable |
| Links and architecture | 90 | 10 | Rules only |
| Structured data and sharing | 95 | 8 | Rules only |
| AI search readiness | 100 | 12 | Rules only: Jev judgments unavailable; editorial heuristics, since Google states no special optimization is required for AI features |
| Performance | 94 | 10 | Crawl observations only: PageSpeed Insights unavailable |
| Security and trust | 100 | 5 | Rules only |
| Search visibility and authority | n/a | 15 | Not assessed: run with --full (DataForSEO) |

<img src="charts/categories.png" alt="Score by area" width="640">

**Contents:** [Executive summary](#executive-summary) · [How this audit was made](#how-this-audit-was-made) · [Priority actions](#priority-actions) · [What the crawl found](#what-the-crawl-found) · [Findings by area](#findings-by-area) · [Robots access](#robots-access) · [Page inventory](#page-inventory) · [Method and limits](#method-and-limits)

## Executive summary

inboxwarm.ai scores 88 out of 100 (grade B) across 7 scored areas. The strongest areas are AI search readiness, security and trust, structured data and sharing; the weakest are crawl and indexing, links and architecture, on-page. The audit produced 25 actions, 3 of them marked fix first and 5 quick wins.

**What is working**

- AI search readiness scores 100.
- Security and trust scores 100.
- Structured data and sharing scores 95.

**What is holding the site back**

- JEV-001: Pages excluded from search with noindex (14 pages carry noindex)
- JEV-002: Pages returning HTTP errors (404)
- JEV-003: Internal links pointing to broken URLs (1 broken targets: 404 https://inboxwarm.ai/blog/Email%20Warm-Up%20API:%20Programmatic%20Warm-Up%20for%20Developers (linked from /blog/email-warm-up-api))

### Plan

**This week**

- JEV-001 Pages excluded from search with noindex
- JEV-004 www and non-www both serve the site
- JEV-007 Duplicate titles across pages
- JEV-009 Redirect chains (more than one hop)

**This month**

- JEV-002 Pages returning HTTP errors
- JEV-003 Internal links pointing to broken URLs
- JEV-005 Missing pages return HTTP 200 (soft 404)
- JEV-006 Slow server response (TTFB above 0.8 s)
- JEV-008 Pages with very little main content

**This quarter**

- JEV-013 Very large HTML documents (over 500 KB)
- JEV-014 Indexable pages missing from the sitemap
- JEV-015 Internal links that go through a redirect
- JEV-016 Heading levels skipped
- JEV-017 Structured data missing properties Google requires for rich results

_Written by: Automatic summary (no lead-agent narrative was written)._

## How this audit was made

A source finds, code decides, Jev judges, Claude writes. Code crawls, counts and scores. Jev (TypeSafe's System One model) answers narrow typed questions about meaning, with probabilities. Missing data is shown as missing.

```mermaid
flowchart LR
  A[Crawl<br/>464 URLs] --> B[Rules<br/>26 findings] --> C[Jev judges<br/>0 judgments] --> D[PageSpeed<br/>0 runs] --> E[Score and write<br/>25 actions]
  style C fill:#d45bb6,color:#fff
```

## Priority actions

<img src="charts/impact_effort.png" alt="Impact versus effort" width="640">

| ID | Action | Priority | Impact | Effort | Pages | By | Verify |
|---|---|---|---:|---|---:|---|---:|
| JEV-001 | Pages excluded from search with noindex (quick win) | P1 Fix first | 100 | Hours | 14 | rule |  |
| JEV-002 | Pages returning HTTP errors | P1 Fix first | 98 | About a day | 1 | rule |  |
| JEV-003 | Internal links pointing to broken URLs | P1 Fix first | 98 | About a day | 1 | rule |  |
| JEV-004 | www and non-www both serve the site (quick win) | P2 Plan next | 82 | Hours | 1 | rule |  |
| JEV-005 | Missing pages return HTTP 200 (soft 404) | P2 Plan next | 82 | About a day | 1 | rule |  |
| JEV-006 | Slow server response (TTFB above 0.8 s) | P2 Plan next | 55 | Several days | 84 | rule |  |
| JEV-007 | Duplicate titles across pages (quick win) | P2 Plan next | 50 | Hours | 19 | rule |  |
| JEV-008 | Pages with very little main content | P2 Plan next | 50 | Several days | 12 | rule |  |
| JEV-009 | Redirect chains (more than one hop) (quick win) | P2 Plan next | 49 | Hours | 1 | rule |  |
| JEV-010 | Canonical points to a different URL (quick win) | P2 Plan next | 49 | Hours | 1 | rule |  |
| JEV-011 | Pages with identical main text | P2 Plan next | 49 | About a day | 2 | rule |  |
| JEV-012 | hreflang annotations incomplete | P2 Plan next | 49 | About a day | 1 | rule |  |
| JEV-013 | Very large HTML documents (over 500 KB) | P3 When convenient | 24 | About a day | 331 | rule |  |
| JEV-014 | Indexable pages missing from the sitemap | P3 When convenient | 19 | Hours | 118 | rule |  |
| JEV-015 | Internal links that go through a redirect | P3 When convenient | 19 | Hours | 109 | rule |  |
| JEV-016 | Heading levels skipped | P3 When convenient | 18 | Hours | 60 | rule |  |
| JEV-017 | Structured data missing properties Google requires for rich results | P3 When convenient | 18 | Hours | 50 | rule |  |
| JEV-018 | Pages without a canonical link | P3 When convenient | 17 | Hours | 12 | rule |  |
| JEV-019 | Very short or very long titles | P3 When convenient | 17 | Hours | 28 | rule |  |
| JEV-020 | Duplicate meta descriptions | P3 When convenient | 17 | Hours | 19 | rule |  |
| JEV-021 | Open Graph title or image missing | P3 When convenient | 17 | Hours | 14 | rule |  |
| JEV-022 | Pages more than three clicks from the homepage | P3 When convenient | 17 | About a day | 11 | rule |  |
| JEV-023 | Internal links with generic anchor text | P3 When convenient | 16 | Hours | 1 | rule |  |
| JEV-024 | Images without width and height | P3 When convenient | 16 | Hours | 2 | rule |  |
| JEV-025 | External links returning errors | P3 When convenient | 16 | Hours | 2 | rule |  |

```mermaid
pie showData title Actions by severity
    "high" : 3
    "medium" : 9
    "low" : 13
```

<img src="charts/severity_by_category.png" alt="Actions by area and severity" width="640">

## What the crawl found

<img src="charts/funnel.png" alt="From discovered URLs to Jev judgments" width="640">

<img src="charts/site_map.png" alt="Site structure by click depth" width="640">

## Findings by area

### Crawl and indexing (68)

**JEV-001 · Pages excluded from search with noindex** `P1` `high` `rule`

- Evidence: 14 affected · 14 pages carry noindex
- Fix: Confirm each noindex is intended; remove it from pages that should rank. ([source](https://developers.google.com/search/docs/crawling-indexing/block-indexing))
- URLs: https://inboxwarm.ai/privacy-policy, https://inboxwarm.ai/terms-of-use, https://inboxwarm.ai/blog/category/cold-email-templates/page/2, https://inboxwarm.ai/blog/category/cold-email-templates/page/4, https://inboxwarm.ai/blog/category/email-deliverability/page/2, https://inboxwarm.ai/blog/category/email-warm-up/page/2, https://inboxwarm.ai/blog/category/cold-email-templates/page/3, https://inboxwarm.ai/blog/author/maryam/page/2 and 6 more

**JEV-002 · Pages returning HTTP errors** `P1` `high` `rule`

- Evidence: 1 affected · 404
- Fix: Restore these URLs or redirect them to the closest live equivalent, and update links. ([source](https://developers.google.com/crawling/docs/troubleshooting/http-status-codes))
- URLs: https://inboxwarm.ai/blog/Email%20Warm-Up%20API:%20Programmatic%20Warm-Up%20for%20Developers

**JEV-004 · www and non-www both serve the site** `P2` `medium` `rule`

- Evidence: 1 affected · www.inboxwarm.ai answers without redirecting to the preferred host
- Fix: Redirect the alternate host to the preferred host with a permanent redirect. ([source](https://developers.google.com/search/docs/crawling-indexing/consolidate-duplicate-urls))
- URLs: https://www.inboxwarm.ai/

**JEV-005 · Missing pages return HTTP 200 (soft 404)** `P2` `medium` `rule`

- Evidence: 1 affected · A random nonexistent URL returned HTTP 200
- Fix: Return a real 404 or 410 status for URLs that do not exist. ([source](https://developers.google.com/crawling/docs/troubleshooting/http-status-codes))
- URLs: https://inboxwarm.ai/jevseo-…-not-found

**JEV-009 · Redirect chains (more than one hop)** `P2` `medium` `rule`

- Evidence: 1 affected · https://inboxwarm.ai/email-warm-up (2 hops)
- Fix: Point each redirect straight at its final URL. ([source](https://developers.google.com/search/docs/crawling-indexing/301-redirects))
- URLs: https://inboxwarm.ai/email-warm-up

**JEV-010 · Canonical points to a different URL** `P2` `medium` `rule`

- Evidence: 1 affected · https://inboxwarm.ai/pricing?billing=yearly&inboxes=10 -> https://inboxwarm.ai/pricing
- Fix: Check that these pages really are duplicates of their canonical target; otherwise self-canonicalise. ([source](https://developers.google.com/search/docs/crawling-indexing/consolidate-duplicate-urls))
- URLs: https://inboxwarm.ai/pricing?billing=yearly&inboxes=10

**JEV-014 · Indexable pages missing from the sitemap** `P3` `low` `rule`

- Evidence: 118 affected · 118 crawled indexable pages are not listed
- Fix: Add these canonical pages to the sitemap. ([source](https://developers.google.com/search/docs/crawling-indexing/sitemaps/overview))
- URLs: https://inboxwarm.ai/blog, https://inboxwarm.ai/blog/category/cold-email-templates, https://inboxwarm.ai/blog/category/email-deliverability, https://inboxwarm.ai/blog/category/email-warm-up, https://inboxwarm.ai/blog/category/cold-email-outreach, https://inboxwarm.ai/blog/category/authentication, https://inboxwarm.ai/blog/category/cold-email-templates/sales, https://inboxwarm.ai/blog/category/cold-email-templates/lead-generation and 110 more

**JEV-018 · Pages without a canonical link** `P3` `low` `rule`

- Evidence: 12 affected · 12 of 461 pages
- Fix: Add a self-referencing rel=canonical to each indexable page. ([source](https://developers.google.com/search/docs/crawling-indexing/consolidate-duplicate-urls))
- URLs: https://inboxwarm.ai/blog/category/cold-email-templates/page/2, https://inboxwarm.ai/blog/category/cold-email-templates/page/4, https://inboxwarm.ai/blog/category/email-deliverability/page/2, https://inboxwarm.ai/blog/category/email-warm-up/page/2, https://inboxwarm.ai/blog/category/cold-email-templates/page/3, https://inboxwarm.ai/blog/author/maryam/page/2, https://inboxwarm.ai/blog/author/maryam/page/3, https://inboxwarm.ai/blog/author/editorialteam-iw/page/2 and 4 more

### On-page (94)

**JEV-007 · Duplicate titles across pages** `P2` `medium` `rule`

- Evidence: 19 affected · 6 titles shared by several pages
- Fix: Give each page a title that distinguishes it from the others. ([source](https://developers.google.com/search/docs/appearance/title-link))
- URLs: https://inboxwarm.ai/blog/author/editorialteam-iw, https://inboxwarm.ai/blog/author/editorialteam-iw/page/2, https://inboxwarm.ai/blog/author/editorialteam-iw/page/3, https://inboxwarm.ai/blog/author/editorialteam-iw/page/4, https://inboxwarm.ai/blog/author/editorialteam-iw/page/5, https://inboxwarm.ai/blog/author/editorialteam-iw/page/6, https://inboxwarm.ai/blog/author/maryam, https://inboxwarm.ai/blog/author/maryam/page/2 and 11 more

**JEV-016 · Heading levels skipped** `P3` `low` `rule` `heuristic`

- Evidence: 60 affected · 60 pages skip a heading level
- Fix: Nest headings in order (H2 under H1, H3 under H2). ([source](https://developers.google.com/search/docs/fundamentals/seo-starter-guide))
- URLs: https://inboxwarm.ai/blog, https://inboxwarm.ai/blog/google-workspace-spf-record-setup, https://inboxwarm.ai/blog/google-yahoo-sender-requirements, https://inboxwarm.ai/blog/how-to-set-up-dkim-microsoft-365, https://inboxwarm.ai/blog/smtp-server-warm-up-guide, https://inboxwarm.ai/blog/how-long-does-email-warm-up-take, https://inboxwarm.ai/blog/smtp-test-passed-but-emails-still-go-to-spam, https://inboxwarm.ai/blog/how-to-get-off-an-email-blacklist and 52 more

**JEV-019 · Very short or very long titles** `P3` `low` `rule` `heuristic`

- Evidence: 28 affected · 68 chars; 69 chars; 68 chars; 78 chars; 68 chars; 67 chars; 67 chars; 70 chars
- Fix: Aim for a concise, descriptive title. Google truncates by pixel width, so there is no fixed limit; 15 to 65 characters is a display convention. ([source](https://developers.google.com/search/docs/appearance/title-link))
- URLs: https://inboxwarm.ai/tools/email-score, https://inboxwarm.ai/blog/google-workspace-spf-record-setup, https://inboxwarm.ai/blog/google-workspace-dmarc-setup, https://inboxwarm.ai/blog/google-yahoo-sender-requirements, https://inboxwarm.ai/blog/best-email-deliverability-tools, https://inboxwarm.ai/blog/how-to-check-domain-reputation, https://inboxwarm.ai/blog/stop-emails-going-to-spam, https://inboxwarm.ai/blog/email-spam-score and 20 more

**JEV-020 · Duplicate meta descriptions** `P3` `low` `rule`

- Evidence: 19 affected · 6 descriptions shared by several pages
- Fix: Write a distinct description for each page. ([source](https://developers.google.com/search/docs/appearance/snippet))
- URLs: https://inboxwarm.ai/blog/author/editorialteam-iw, https://inboxwarm.ai/blog/author/editorialteam-iw/page/2, https://inboxwarm.ai/blog/author/editorialteam-iw/page/3, https://inboxwarm.ai/blog/author/editorialteam-iw/page/4, https://inboxwarm.ai/blog/author/editorialteam-iw/page/5, https://inboxwarm.ai/blog/author/editorialteam-iw/page/6, https://inboxwarm.ai/blog/author/maryam, https://inboxwarm.ai/blog/author/maryam/page/2 and 11 more

### Content quality (n/a)

**JEV-008 · Pages with very little main content** `P2` `medium` `rule` `heuristic`

- Evidence: 12 affected · /zh/about: 97 words; /ja/about: 43 words; /zh/tools/spam-test: 109 words; /ja/tools/spam-test: 66 words; /ja/email-warmup/smtp: 113 words; /ja/tools/ssl-checker: 129 words; /ja/tools/whois-checker: 111 words; /ja/tools/cname-checker: 116 words
- Fix: Expand pages that should rank with substance a visitor needs, or consolidate them. Word count is a warning sign, not a ranking factor. ([source](https://developers.google.com/search/docs/fundamentals/creating-helpful-content))
- URLs: https://inboxwarm.ai/zh/about, https://inboxwarm.ai/ja/about, https://inboxwarm.ai/zh/tools/spam-test, https://inboxwarm.ai/ja/tools/spam-test, https://inboxwarm.ai/ja/email-warmup/smtp, https://inboxwarm.ai/ja/tools/ssl-checker, https://inboxwarm.ai/ja/tools/whois-checker, https://inboxwarm.ai/ja/tools/cname-checker and 4 more

**JEV-011 · Pages with identical main text** `P2` `medium` `rule`

- Evidence: 2 affected · 1 group of pages with identical main text
- Fix: Consolidate duplicates or canonicalise them to one URL. ([source](https://developers.google.com/search/docs/crawling-indexing/consolidate-duplicate-urls))
- URLs: https://inboxwarm.ai/pricing, https://inboxwarm.ai/pricing?billing=yearly&inboxes=10

### Links and architecture (90)

**JEV-003 · Internal links pointing to broken URLs** `P1` `high` `rule`

- Evidence: 1 affected · 1 broken targets: 404 https://inboxwarm.ai/blog/Email%20Warm-Up%20API:%20Programmatic%20Warm-Up%20for%20Developers (linked from /blog/email-warm-up-api)
- Fix: Update or remove links that point to 4xx, 5xx or unreachable URLs. ([source](https://developers.google.com/crawling/docs/troubleshooting/http-status-codes))
- URLs: https://inboxwarm.ai/blog/email-warm-up-api

**JEV-015 · Internal links that go through a redirect** `P3` `low` `rule`

- Evidence: 109 affected · / links to /email-warm-up (redirects to /email-warmup); /pricing links to /email-warm-up (redirects to /email-warmup); /pricing links to /email-warm-up (redirects to /email-warmup); /api links to /email-warm-up (redirects to /email-warmup); /email-warmup/gmail links to /email-warm-up (redirects to /email-warmup); and 104 more
- Fix: Link directly to the final URL. ([source](https://developers.google.com/search/docs/crawling-indexing/301-redirects))
- URLs: https://inboxwarm.ai/, https://inboxwarm.ai/about, https://inboxwarm.ai/api, https://inboxwarm.ai/api/docs, https://inboxwarm.ai/blog/best-email-warm-up-tools, https://inboxwarm.ai/blog/warmbox-alternatives, https://inboxwarm.ai/cold-email-roi-calculator, https://inboxwarm.ai/compare/inboxwarm-vs-instantly and 101 more

**JEV-022 · Pages more than three clicks from the homepage** `P3` `low` `rule` `heuristic`

- Evidence: 11 affected · 11 pages deeper than three clicks
- Fix: Link important deep pages from hubs or navigation closer to the homepage. ([source](https://developers.google.com/search/docs/crawling-indexing/links-crawlable))
- URLs: https://inboxwarm.ai/blog/category/cold-email-templates/page/3, https://inboxwarm.ai/blog/why-cold-emails-go-to-spam, https://inboxwarm.ai/blog/sender-score-guide, https://inboxwarm.ai/blog/spam-trigger-words-list, https://inboxwarm.ai/blog/author/maryam/page/2, https://inboxwarm.ai/blog/author/maryam/page/3, https://inboxwarm.ai/blog/author/editorialteam-iw/page/2, https://inboxwarm.ai/blog/author/editorialteam-iw/page/6 and 3 more

**JEV-023 · Internal links with generic anchor text** `P3` `low` `rule`

- Evidence: 1 affected · Anchors such as: READ MORE
- Fix: Use anchor text that describes the destination. ([source](https://developers.google.com/search/docs/crawling-indexing/links-crawlable))
- URLs: https://inboxwarm.ai/blog

**JEV-025 · External links returning errors** `P3` `low` `rule`

- Evidence: 2 affected · 2 of 80 sampled outbound links
- Fix: Update or remove outbound links that no longer resolve. ([source](https://developers.google.com/crawling/docs/troubleshooting/http-status-codes))
- URLs: https://documentation.mailgun.com/docs/mailgun/api-reference/openapi-final/ip-address-warmup, https://www.gong.io/wp-content/uploads/2023/01/11-Hyper-Persuasive-Sales-Email-Templates.pdf

### Structured data and sharing (95)

**JEV-012 · hreflang annotations incomplete** `P2` `medium` `rule`

- Evidence: 1 affected · 1 page with hreflang but no self-reference
- Fix: Each language version needs a self-reference and return links; add x-default where useful. ([source](https://developers.google.com/search/docs/specialty/international/localized-versions))
- URLs: https://inboxwarm.ai/pricing?billing=yearly&inboxes=10

**JEV-017 · Structured data missing properties Google requires for rich results** `P3` `low` `rule`

- Evidence: 50 affected · SoftwareApplication on / lacks offers.price, aggregateRating or review; SoftwareApplication on /api lacks offers.price, aggregateRating or review; SoftwareApplication on /email-warmup lacks offers.price, aggregateRating or review; SoftwareApplication on /email-deliverability lacks offers.price, aggregateRating or review; SoftwareApplication on /email-infrastructure lacks offers.price, aggregateRating or review; SoftwareApplication on /zh lacks offers.price, aggregateRating or review; and 44 more
- Fix: Add the missing required properties listed in the evidence, or remove markup that cannot be completed truthfully. ([source](https://developers.google.com/search/docs/appearance/structured-data/intro-structured-data))
- URLs: https://inboxwarm.ai/, https://inboxwarm.ai/api, https://inboxwarm.ai/ar, https://inboxwarm.ai/ar/api, https://inboxwarm.ai/ar/email-deliverability, https://inboxwarm.ai/ar/email-infrastructure, https://inboxwarm.ai/ar/email-warmup, https://inboxwarm.ai/de and 42 more

**JEV-021 · Open Graph title or image missing** `P3` `low` `rule`

- Evidence: 14 affected · 14 pages lack og:title or og:image
- Fix: Add og:title, og:description and og:image for link previews. ([source](https://ogp.me/))
- URLs: https://inboxwarm.ai/blog/category/cold-email-templates, https://inboxwarm.ai/blog/category/email-deliverability, https://inboxwarm.ai/blog/category/email-warm-up, https://inboxwarm.ai/blog/category/cold-email-outreach, https://inboxwarm.ai/blog/category/authentication, https://inboxwarm.ai/blog/category/cold-email-templates/sales, https://inboxwarm.ai/blog/category/cold-email-templates/lead-generation, https://inboxwarm.ai/blog/category/cold-email-templates/networking and 6 more

### Performance (94)



**JEV-006 · Slow server response (TTFB above 0.8 s)** `P2` `medium` `rule`

- Evidence: 84 affected · /blog/category/cold-email-outreach: 1263 ms; /blog/category/cold-email-templates/sales: 1235 ms; /blog/category/cold-email-templates/lead-generation: 1228 ms; /blog/category/cold-email-templates/networking: 1264 ms; /blog/category/cold-email-templates/follow-up: 1201 ms; /blog/follow-up-email-after-free-trial-ends: 1296 ms
- Fix: Cache pages, use a CDN and reduce server work before the first byte. ([source](https://web.dev/articles/ttfb))
- URLs: https://inboxwarm.ai/blog/category/cold-email-outreach, https://inboxwarm.ai/blog/category/cold-email-templates/sales, https://inboxwarm.ai/blog/category/cold-email-templates/lead-generation, https://inboxwarm.ai/blog/category/cold-email-templates/networking, https://inboxwarm.ai/blog/category/cold-email-templates/follow-up, https://inboxwarm.ai/blog/follow-up-email-after-free-trial-ends, https://inboxwarm.ai/blog/follow-up-email-after-sending-information, https://inboxwarm.ai/blog/follow-up-email-after-sending-pricing and 76 more

**JEV-013 · Very large HTML documents (over 500 KB)** `P3` `low` `rule` `heuristic`

- Evidence: 331 affected · /: 704 KB; /pricing: 584 KB; /pricing: 584 KB; /api: 607 KB; /email-warmup/gmail: 585 KB; /email-warmup/outlook: 581 KB
- Fix: Trim inline data and markup that ships with every page. ([source](https://web.dev/articles/vitals))
- URLs: https://inboxwarm.ai/, https://inboxwarm.ai/pricing?billing=yearly&inboxes=10, https://inboxwarm.ai/pricing, https://inboxwarm.ai/api, https://inboxwarm.ai/email-warmup/gmail, https://inboxwarm.ai/email-warmup/outlook, https://inboxwarm.ai/email-warmup/amazon-ses, https://inboxwarm.ai/email-warmup/sendgrid and 323 more

**JEV-024 · Images without width and height** `P3` `low` `rule`

- Evidence: 2 affected · 2 images without explicit size
- Fix: Set width and height so layout does not shift while images load. ([source](https://web.dev/articles/optimize-cls))
- URLs: https://inboxwarm.ai/blog/author/maryam, https://inboxwarm.ai/blog/author/editorialteam-iw

## Robots access

| User agent | Access |
|---|---|
| Googlebot | allowed |
| Bingbot | allowed |
| GPTBot | allowed |
| OAI-SearchBot | allowed |
| ChatGPT-User | allowed |
| ClaudeBot | allowed |
| Claude-SearchBot | allowed |
| PerplexityBot | allowed |
| Google-Extended | allowed |
| Applebot-Extended | allowed |
| CCBot | allowed |
| Bytespider | allowed |

## Page inventory

| Page | Depth | Words | Inlinks | Type (Jev) | Intent (Jev) | Importance | Action (Jev) |
|---|---:|---:|---:|---|---|---:|---|
| https://inboxwarm.ai/ | 0 | 2767 | 238 |  |  |  |  |
| https://inboxwarm.ai/about | 1 | 443 | 236 |  |  |  |  |
| https://inboxwarm.ai/api | 1 | 1336 | 236 |  |  |  |  |
| https://inboxwarm.ai/api/docs | 1 | 2752 | 236 |  |  |  |  |
| https://inboxwarm.ai/blog | 1 | 771 | 460 |  |  |  |  |
| https://inboxwarm.ai/cold-email-roi-calculator | 1 | 636 | 236 |  |  |  |  |
| https://inboxwarm.ai/compare/inboxwarm-vs-instantly | 1 | 1612 | 236 |  |  |  |  |
| https://inboxwarm.ai/compare/inboxwarm-vs-lemwarm | 1 | 1683 | 245 |  |  |  |  |
| https://inboxwarm.ai/compare/inboxwarm-vs-mailreach | 1 | 1667 | 245 |  |  |  |  |
| https://inboxwarm.ai/compare/inboxwarm-vs-warmbox | 1 | 1600 | 236 |  |  |  |  |
| https://inboxwarm.ai/compare/inboxwarm-vs-warmup-inbox | 1 | 1700 | 245 |  |  |  |  |
| https://inboxwarm.ai/compare/inboxwarm-vs-warmy | 1 | 1591 | 236 |  |  |  |  |
| https://inboxwarm.ai/email-deliverability | 1 | 455 | 236 |  |  |  |  |
| https://inboxwarm.ai/email-infrastructure | 1 | 466 | 236 |  |  |  |  |
| https://inboxwarm.ai/email-warmup | 1 | 1375 | 343 |  |  |  |  |
| https://inboxwarm.ai/email-warmup/amazon-ses | 1 | 951 | 236 |  |  |  |  |
| https://inboxwarm.ai/email-warmup/gmail | 1 | 1006 | 236 |  |  |  |  |
| https://inboxwarm.ai/email-warmup/mailgun | 1 | 781 | 236 |  |  |  |  |
| https://inboxwarm.ai/email-warmup/outlook | 1 | 888 | 236 |  |  |  |  |
| https://inboxwarm.ai/email-warmup/sendgrid | 1 | 950 | 236 |  |  |  |  |
| https://inboxwarm.ai/email-warmup/smtp | 1 | 770 | 236 |  |  |  |  |
| https://inboxwarm.ai/glossary | 1 | 1995 | 460 |  |  |  |  |
| https://inboxwarm.ai/pricing | 1 | 1138 | 236 |  |  |  |  |
| https://inboxwarm.ai/pricing?billing=yearly&inboxes=10 | 1 | 1138 | 40 |  |  |  |  |
| https://inboxwarm.ai/privacy-policy | 1 | 3436 | 460 |  |  |  |  |
| https://inboxwarm.ai/terms-of-use | 1 | 2748 | 460 |  |  |  |  |
| https://inboxwarm.ai/tools/a-record-checker | 1 | 911 | 236 |  |  |  |  |
| https://inboxwarm.ai/tools/bimi-checker | 1 | 859 | 236 |  |  |  |  |
| https://inboxwarm.ai/tools/cname-checker | 1 | 914 | 236 |  |  |  |  |
| https://inboxwarm.ai/tools/deliverability-checklist | 1 | 3323 | 236 |  |  |  |  |
| https://inboxwarm.ai/tools/dkim-checker | 1 | 966 | 236 |  |  |  |  |
| https://inboxwarm.ai/tools/dmarc-checker | 1 | 1022 | 236 |  |  |  |  |
| https://inboxwarm.ai/tools/dmarc-generator | 1 | 1157 | 236 |  |  |  |  |
| https://inboxwarm.ai/tools/domain-email-health-checker | 1 | 773 | 236 |  |  |  |  |
| https://inboxwarm.ai/tools/email-header-analyzer | 1 | 875 | 236 |  |  |  |  |
| https://inboxwarm.ai/tools/email-score | 1 | 379 | 236 |  |  |  |  |
| https://inboxwarm.ai/tools/esp-checker | 1 | 847 | 236 |  |  |  |  |
| https://inboxwarm.ai/tools/mta-sts-checker | 1 | 909 | 236 |  |  |  |  |
| https://inboxwarm.ai/tools/spam-test | 1 | 861 | 236 |  |  |  |  |
| https://inboxwarm.ai/tools/spam-word-checker | 1 | 791 | 236 |  |  |  |  |
| https://inboxwarm.ai/tools/spf-checker | 1 | 845 | 236 |  |  |  |  |
| https://inboxwarm.ai/tools/spf-generator | 1 | 948 | 236 |  |  |  |  |
| https://inboxwarm.ai/tools/ssl-checker | 1 | 847 | 236 |  |  |  |  |
| https://inboxwarm.ai/tools/subject-line-tester | 1 | 1201 | 236 |  |  |  |  |
| https://inboxwarm.ai/tools/whois-checker | 1 | 816 | 236 |  |  |  |  |
| https://inboxwarm.ai/blog/automated-email-warmup | 2 | 2955 | 25 |  |  |  |  |
| https://inboxwarm.ai/blog/category/authentication | 2 | 1453 | 125 |  |  |  |  |
| https://inboxwarm.ai/blog/category/cold-email-outreach | 2 | 1440 | 126 |  |  |  |  |
| https://inboxwarm.ai/blog/category/cold-email-templates | 2 | 1501 | 124 |  |  |  |  |
| https://inboxwarm.ai/blog/category/cold-email-templates/follow-up | 2 | 1266 | 121 |  |  |  |  |
| https://inboxwarm.ai/blog/category/cold-email-templates/lead-generation | 2 | 1405 | 123 |  |  |  |  |
| https://inboxwarm.ai/blog/category/cold-email-templates/link-building-digital-pr | 2 | 1275 | 121 |  |  |  |  |
| https://inboxwarm.ai/blog/category/cold-email-templates/networking | 2 | 1492 | 122 |  |  |  |  |
| https://inboxwarm.ai/blog/category/cold-email-templates/sales | 2 | 1376 | 124 |  |  |  |  |
| https://inboxwarm.ai/blog/category/comparison | 2 | 1358 | 124 |  |  |  |  |
| https://inboxwarm.ai/blog/category/email-deliverability | 2 | 1523 | 125 |  |  |  |  |
| https://inboxwarm.ai/blog/category/email-troubleshooting | 2 | 1427 | 124 |  |  |  |  |
| https://inboxwarm.ai/blog/category/email-warm-up | 2 | 1425 | 126 |  |  |  |  |
| https://inboxwarm.ai/blog/category/marketing | 2 | 1251 | 121 |  |  |  |  |
| https://inboxwarm.ai/blog/category/saas-growth | 2 | 1247 | 121 |  |  |  |  |
| https://inboxwarm.ai/blog/cold-email-asking-an-expert-for-advice | 2 | 1832 | 8 |  |  |  |  |
| https://inboxwarm.ai/blog/follow-up-email-after-free-trial-ends | 2 | 1514 | 40 |  |  |  |  |
| https://inboxwarm.ai/blog/follow-up-email-after-missed-meeting | 2 | 1541 | 6 |  |  |  |  |
| https://inboxwarm.ai/blog/follow-up-email-after-networking-event | 2 | 1595 | 8 |  |  |  |  |
| https://inboxwarm.ai/blog/follow-up-email-after-positive-reply | 2 | 1477 | 40 |  |  |  |  |
| https://inboxwarm.ai/blog/follow-up-email-after-product-demo | 2 | 1856 | 6 |  |  |  |  |
| https://inboxwarm.ai/blog/follow-up-email-after-sending-information | 2 | 1575 | 8 |  |  |  |  |
| https://inboxwarm.ai/blog/follow-up-email-after-sending-pricing | 2 | 1719 | 6 |  |  |  |  |
| https://inboxwarm.ai/blog/follow-up-email-after-sending-proposal | 2 | 1480 | 6 |  |  |  |  |
| https://inboxwarm.ai/blog/follow-up-email-check-back-later | 2 | 1824 | 7 |  |  |  |  |
| https://inboxwarm.ai/blog/follow-up-email-internal-approval | 2 | 1630 | 6 |  |  |  |  |
| https://inboxwarm.ai/blog/free-email-warmup | 2 | 3431 | 16 |  |  |  |  |
| https://inboxwarm.ai/blog/google-workspace-dmarc-setup | 2 | 4402 | 14 |  |  |  |  |
| https://inboxwarm.ai/blog/google-workspace-spf-record-setup | 2 | 4150 | 22 |  |  |  |  |
| https://inboxwarm.ai/blog/google-yahoo-sender-requirements | 2 | 4776 | 19 |  |  |  |  |
| https://inboxwarm.ai/blog/how-long-does-email-warm-up-take | 2 | 3165 | 18 |  |  |  |  |
| https://inboxwarm.ai/blog/how-to-set-up-dkim-microsoft-365 | 2 | 3149 | 24 |  |  |  |  |
| https://inboxwarm.ai/blog/industry-peer-cold-email-template | 2 | 1615 | 6 |  |  |  |  |
| https://inboxwarm.ai/blog/informational-interview-email-template | 2 | 2240 | 6 |  |  |  |  |
| https://inboxwarm.ai/blog/ip-warm-up-vs-domain-warm-up | 2 | 2547 | 41 |  |  |  |  |
| https://inboxwarm.ai/blog/job-reference-request-email-template | 2 | 1836 | 6 |  |  |  |  |
| https://inboxwarm.ai/blog/job-referral-email-template | 2 | 1852 | 6 |  |  |  |  |
| https://inboxwarm.ai/blog/mutual-connection-introduction-email | 2 | 1450 | 10 |  |  |  |  |
| https://inboxwarm.ai/blog/pre-event-networking-email-template | 2 | 1643 | 6 |  |  |  |  |
| https://inboxwarm.ai/blog/reconnect-with-former-colleague-email-template | 2 | 1639 | 6 |  |  |  |  |
| https://inboxwarm.ai/blog/smtp-server-warm-up-guide | 2 | 3700 | 17 |  |  |  |  |
| https://inboxwarm.ai/blog/unlinked-brand-mention-outreach-email | 2 | 1843 | 39 |  |  |  |  |
| https://inboxwarm.ai/blog/useful-resource-cold-email-templates | 2 | 2780 | 13 |  |  |  |  |
| https://inboxwarm.ai/glossary/a-record | 2 | 550 | 4 |  |  |  |  |
| https://inboxwarm.ai/glossary/auto-reply | 2 | 592 | 1 |  |  |  |  |
| https://inboxwarm.ai/glossary/blacklist | 2 | 692 | 4 |  |  |  |  |
| https://inboxwarm.ai/glossary/bounce-rate | 2 | 648 | 3 |  |  |  |  |
| https://inboxwarm.ai/glossary/built-in-esp-warmup | 2 | 538 | 2 |  |  |  |  |
| https://inboxwarm.ai/glossary/cold-domain | 2 | 605 | 3 |  |  |  |  |
| https://inboxwarm.ai/glossary/cold-email | 2 | 620 | 3 |  |  |  |  |
| https://inboxwarm.ai/glossary/cold-ip | 2 | 585 | 4 |  |  |  |  |
| https://inboxwarm.ai/glossary/complaint-rate | 2 | 593 | 10 |  |  |  |  |
| https://inboxwarm.ai/glossary/custom-tracking-domain | 2 | 597 | 1 |  |  |  |  |
| https://inboxwarm.ai/glossary/dedicated-ip | 2 | 620 | 8 |  |  |  |  |
| https://inboxwarm.ai/glossary/deliverability-audit | 2 | 557 | 2 |  |  |  |  |
| https://inboxwarm.ai/glossary/dkim | 2 | 650 | 4 |  |  |  |  |
| https://inboxwarm.ai/glossary/dmarc | 2 | 683 | 7 |  |  |  |  |
| https://inboxwarm.ai/glossary/domain-age | 2 | 612 | 3 |  |  |  |  |
| https://inboxwarm.ai/glossary/domain-reputation | 2 | 602 | 15 |  |  |  |  |
| https://inboxwarm.ai/glossary/email-authentication | 2 | 626 | 15 |  |  |  |  |
| https://inboxwarm.ai/glossary/email-deliverability | 2 | 567 | 11 |  |  |  |  |
| https://inboxwarm.ai/glossary/email-engagement | 2 | 610 | 9 |  |  |  |  |
| https://inboxwarm.ai/glossary/email-infrastructure | 2 | 582 | 8 |  |  |  |  |
| https://inboxwarm.ai/glossary/email-queue | 2 | 309 | 1 |  |  |  |  |
| https://inboxwarm.ai/glossary/email-volume-ramp-up | 2 | 651 | 8 |  |  |  |  |
| https://inboxwarm.ai/glossary/email-warm-up | 2 | 681 | 17 |  |  |  |  |
| https://inboxwarm.ai/glossary/engagement-pod | 2 | 617 | 7 |  |  |  |  |
| https://inboxwarm.ai/glossary/esp | 2 | 583 | 5 |  |  |  |  |
| https://inboxwarm.ai/glossary/feedback-loop | 2 | 604 | 4 |  |  |  |  |
| https://inboxwarm.ai/glossary/folder-placement | 2 | 588 | 4 |  |  |  |  |
| https://inboxwarm.ai/glossary/forward-dns | 2 | 585 | 4 |  |  |  |  |
| https://inboxwarm.ai/glossary/gmail-postmaster-tools | 2 | 664 | 7 |  |  |  |  |
| https://inboxwarm.ai/glossary/greylisting | 2 | 606 | 1 |  |  |  |  |
| https://inboxwarm.ai/glossary/human-like-sending-patterns | 2 | 597 | 1 |  |  |  |  |
| https://inboxwarm.ai/glossary/inbox-placement-rate | 2 | 603 | 6 |  |  |  |  |
| https://inboxwarm.ai/glossary/inbox-testing | 2 | 632 | 5 |  |  |  |  |
| https://inboxwarm.ai/glossary/ip-reputation | 2 | 595 | 11 |  |  |  |  |
| https://inboxwarm.ai/glossary/ip-warm-up | 2 | 666 | 14 |  |  |  |  |
| https://inboxwarm.ai/glossary/jmrp | 2 | 298 | 1 |  |  |  |  |
| https://inboxwarm.ai/glossary/junk-folder | 2 | 293 | 2 |  |  |  |  |
| https://inboxwarm.ai/glossary/microsoft-snds | 2 | 597 | 5 |  |  |  |  |
| https://inboxwarm.ai/glossary/mx-record | 2 | 628 | 2 |  |  |  |  |
| https://inboxwarm.ai/glossary/negative-engagement-signals | 2 | 628 | 3 |  |  |  |  |
| https://inboxwarm.ai/glossary/open-rate | 2 | 634 | 3 |  |  |  |  |
| https://inboxwarm.ai/glossary/outreach-sequence | 2 | 562 | 3 |  |  |  |  |
| https://inboxwarm.ai/glossary/positive-engagement-signals | 2 | 606 | 5 |  |  |  |  |
| https://inboxwarm.ai/glossary/ptr-record | 2 | 679 | 6 |  |  |  |  |
| https://inboxwarm.ai/glossary/quarantine | 2 | 328 | 1 |  |  |  |  |
| https://inboxwarm.ai/glossary/ramp-up-schedule | 2 | 578 | 3 |  |  |  |  |
| https://inboxwarm.ai/glossary/reply-rate | 2 | 628 | 6 |  |  |  |  |
| https://inboxwarm.ai/glossary/reputation-recovery | 2 | 637 | 3 |  |  |  |  |
| https://inboxwarm.ai/glossary/return-path | 2 | 632 | 4 |  |  |  |  |
| https://inboxwarm.ai/glossary/seed-accounts | 2 | 627 | 3 |  |  |  |  |
| https://inboxwarm.ai/glossary/sender-score | 2 | 599 | 2 |  |  |  |  |
| https://inboxwarm.ai/glossary/sending-limits | 2 | 633 | 2 |  |  |  |  |
| https://inboxwarm.ai/glossary/shared-ip-pool | 2 | 601 | 4 |  |  |  |  |
| https://inboxwarm.ai/glossary/spam-filter | 2 | 675 | 9 |  |  |  |  |
| https://inboxwarm.ai/glossary/spf | 2 | 727 | 6 |  |  |  |  |
| https://inboxwarm.ai/glossary/suppression-list | 2 | 595 | 7 |  |  |  |  |
| https://inboxwarm.ai/glossary/throttling | 2 | 618 | 1 |  |  |  |  |
| https://inboxwarm.ai/glossary/tls | 2 | 614 | 1 |  |  |  |  |
| https://inboxwarm.ai/glossary/unsubscribe-rate | 2 | 611 | 1 |  |  |  |  |
| https://inboxwarm.ai/glossary/volume-spike | 2 | 650 | 3 |  |  |  |  |
| https://inboxwarm.ai/glossary/warm-up-dashboard | 2 | 606 | 1 |  |  |  |  |
| https://inboxwarm.ai/glossary/warm-up-network | 2 | 582 | 5 |  |  |  |  |
| https://inboxwarm.ai/glossary/zero-day-domain-risk | 2 | 629 | 3 |  |  |  |  |
| https://inboxwarm.ai/blog/550-permanent-failure | 3 | 3516 | 5 |  |  |  |  |
| https://inboxwarm.ai/blog/author/editorialteam-iw | 3 | 531 | 70 |  |  |  |  |
| https://inboxwarm.ai/blog/author/maryam | 3 | 560 | 38 |  |  |  |  |
| https://inboxwarm.ai/blog/b2b-lead-generation-cold-email-template | 3 | 3090 | 15 |  |  |  |  |
| https://inboxwarm.ai/blog/b2b-saas-customer-support-software | 3 | 5419 | 4 |  |  |  |  |
| https://inboxwarm.ai/blog/best-cold-email-tools | 3 | 3563 | 14 |  |  |  |  |
| https://inboxwarm.ai/blog/best-email-deliverability-tools | 3 | 3127 | 7 |  |  |  |  |
| https://inboxwarm.ai/blog/best-email-warm-up-tools | 3 | 4626 | 7 |  |  |  |  |
| https://inboxwarm.ai/blog/bounced-email-guide | 3 | 3543 | 8 |  |  |  |  |
| https://inboxwarm.ai/blog/case-study-cold-email-template | 3 | 3004 | 5 |  |  |  |  |
| https://inboxwarm.ai/blog/category/cold-email-templates/page/2 | 3 | 245 | 2 |  |  |  |  |
| https://inboxwarm.ai/blog/category/cold-email-templates/page/4 | 3 | 148 | 3 |  |  |  |  |
| https://inboxwarm.ai/blog/category/email-deliverability/page/2 | 3 | 179 | 1 |  |  |  |  |
| https://inboxwarm.ai/blog/category/email-warm-up/page/2 | 3 | 148 | 1 |  |  |  |  |
| https://inboxwarm.ai/blog/cold-email-best-practices | 3 | 2692 | 14 |  |  |  |  |
| https://inboxwarm.ai/blog/cold-email-daily-sending-limit | 3 | 1952 | 15 |  |  |  |  |
| https://inboxwarm.ai/blog/cold-email-deliverability | 3 | 3518 | 9 |  |  |  |  |
| https://inboxwarm.ai/blog/cold-email-deliverability-examples | 3 | 3957 | 6 |  |  |  |  |
| https://inboxwarm.ai/blog/cold-email-open-tracking | 3 | 3652 | 4 |  |  |  |  |
| https://inboxwarm.ai/blog/cold-email-statistics | 3 | 1842 | 18 |  |  |  |  |
| https://inboxwarm.ai/blog/cold-email-template-low-reply-rates | 3 | 2663 | 9 |  |  |  |  |
| https://inboxwarm.ai/blog/cold-email-template-new-sales-domain | 3 | 3176 | 5 |  |  |  |  |
| https://inboxwarm.ai/blog/company-research-cold-email-templates | 3 | 3155 | 6 |  |  |  |  |
| https://inboxwarm.ai/blog/competitor-switch-email-template | 3 | 2759 | 6 |  |  |  |  |
| https://inboxwarm.ai/blog/complementary-tool-cold-email-templates | 3 | 3067 | 5 |  |  |  |  |
| https://inboxwarm.ai/blog/creative-brief-guide | 3 | 6825 | 4 |  |  |  |  |
| https://inboxwarm.ai/blog/dmarc-fail | 3 | 3466 | 6 |  |  |  |  |
| https://inboxwarm.ai/blog/does-email-warm-up-work | 3 | 3377 | 4 |  |  |  |  |
| https://inboxwarm.ai/blog/email-bounce-back | 3 | 4030 | 4 |  |  |  |  |
| https://inboxwarm.ai/blog/email-deliverability-audit-checklist | 3 | 3569 | 17 |  |  |  |  |
| https://inboxwarm.ai/blog/email-deliverability-guide | 3 | 4096 | 17 |  |  |  |  |
| https://inboxwarm.ai/blog/email-deliverability-statistics | 3 | 4678 | 4 |  |  |  |  |
| https://inboxwarm.ai/blog/email-error-codes | 3 | 4600 | 8 |  |  |  |  |
| https://inboxwarm.ai/blog/email-reputation-check | 3 | 3965 | 4 |  |  |  |  |
| https://inboxwarm.ai/blog/email-spam-score | 3 | 3811 | 9 |  |  |  |  |
| https://inboxwarm.ai/blog/email-warm-up | 3 | 3370 | 38 |  |  |  |  |
| https://inboxwarm.ai/blog/email-warm-up-api | 3 | 2851 | 6 |  |  |  |  |
| https://inboxwarm.ai/blog/email-warmup-vs-email-deliverability | 3 | 2864 | 16 |  |  |  |  |
| https://inboxwarm.ai/blog/fix-5-7-5-permanent-error | 3 | 3882 | 10 |  |  |  |  |
| https://inboxwarm.ai/blog/gmail-smtp-settings | 3 | 3345 | 7 |  |  |  |  |
| https://inboxwarm.ai/blog/google-workspace-mx-record | 3 | 4756 | 13 |  |  |  |  |
| https://inboxwarm.ai/blog/hard-bounce-vs-soft-bounce | 3 | 3839 | 10 |  |  |  |  |
| https://inboxwarm.ai/blog/hiring-signal-cold-email-templates | 3 | 3144 | 5 |  |  |  |  |
| https://inboxwarm.ai/blog/how-to-check-domain-reputation | 3 | 4262 | 5 |  |  |  |  |
| https://inboxwarm.ai/blog/how-to-follow-up-on-a-cold-email | 3 | 2979 | 4 |  |  |  |  |
| https://inboxwarm.ai/blog/how-to-get-off-an-email-blacklist | 3 | 3514 | 19 |  |  |  |  |
| https://inboxwarm.ai/blog/how-to-improve-email-deliverability | 3 | 4000 | 5 |  |  |  |  |
| https://inboxwarm.ai/blog/how-to-recover-a-damaged-email-domain | 3 | 2959 | 13 |  |  |  |  |
| https://inboxwarm.ai/blog/how-to-warm-up-email-domain | 3 | 3750 | 6 |  |  |  |  |
| https://inboxwarm.ai/blog/html-vs-plain-text-emails | 3 | 3190 | 4 |  |  |  |  |
| https://inboxwarm.ai/blog/leadership-change-cold-email-templates | 3 | 3094 | 5 |  |  |  |  |
| https://inboxwarm.ai/blog/lemwarm-alternatives | 3 | 3527 | 8 |  |  |  |  |
| https://inboxwarm.ai/blog/lemwarm-vs-instantly-vs-inboxwarm | 3 | 3138 | 5 |  |  |  |  |
| https://inboxwarm.ai/blog/market-expansion-cold-email-templates | 3 | 3060 | 5 |  |  |  |  |
| https://inboxwarm.ai/blog/multi-domain-warm-up | 3 | 2958 | 4 |  |  |  |  |
| https://inboxwarm.ai/blog/mx-record-explained | 3 | 4087 | 6 |  |  |  |  |
| https://inboxwarm.ai/blog/newly-funded-companies-cold-email-templates | 3 | 3050 | 5 |  |  |  |  |
| https://inboxwarm.ai/blog/primary-domain-vs-cold-email-domain | 3 | 2822 | 4 |  |  |  |  |
| https://inboxwarm.ai/blog/problem-solution-cold-email-template | 3 | 1690 | 9 |  |  |  |  |
| https://inboxwarm.ai/blog/product-discovery-email-template | 3 | 2250 | 8 |  |  |  |  |
| https://inboxwarm.ai/blog/prospect-needs-validation-cold-email-templates | 3 | 3088 | 10 |  |  |  |  |
| https://inboxwarm.ai/blog/reaching-decision-makers-email-template | 3 | 3172 | 7 |  |  |  |  |
| https://inboxwarm.ai/blog/sales-emails-going-to-spam-cold-email-template | 3 | 2836 | 5 |  |  |  |  |
| https://inboxwarm.ai/blog/sales-follow-up-email-templates | 3 | 5178 | 10 |  |  |  |  |
| https://inboxwarm.ai/blog/smtp-test-passed-but-emails-still-go-to-spam | 3 | 2609 | 18 |  |  |  |  |
| https://inboxwarm.ai/blog/smtp-warmup | 3 | 3230 | 4 |  |  |  |  |
| https://inboxwarm.ai/blog/spf-dkim-and-dmarc-explained | 3 | 3892 | 34 |  |  |  |  |
| https://inboxwarm.ai/blog/spf-vs-dkim-vs-dmarc | 3 | 3705 | 5 |  |  |  |  |
| https://inboxwarm.ai/blog/stop-emails-going-to-spam | 3 | 3395 | 8 |  |  |  |  |
| https://inboxwarm.ai/blog/value-proposition-sales-cold-email-template | 3 | 2934 | 5 |  |  |  |  |
| https://inboxwarm.ai/blog/warmbox-alternatives | 3 | 3975 | 8 |  |  |  |  |
| https://inboxwarm.ai/blog/warmy-io-alternatives | 3 | 3952 | 8 |  |  |  |  |
| https://inboxwarm.ai/blog/what-is-dkim | 3 | 4548 | 6 |  |  |  |  |
| https://inboxwarm.ai/blog/what-is-sender-score | 3 | 3544 | 4 |  |  |  |  |
| https://inboxwarm.ai/blog/what-is-spf-record | 3 | 2913 | 7 |  |  |  |  |
| https://inboxwarm.ai/blog/author/editorialteam-iw/page/2 | 4 | 228 | 2 |  |  |  |  |
| https://inboxwarm.ai/blog/author/editorialteam-iw/page/6 | 4 | 162 | 5 |  |  |  |  |
| https://inboxwarm.ai/blog/author/maryam/page/2 | 4 | 213 | 2 |  |  |  |  |
| https://inboxwarm.ai/blog/author/maryam/page/3 | 4 | 213 | 2 |  |  |  |  |
| https://inboxwarm.ai/blog/category/cold-email-templates/page/3 | 4 | 242 | 2 |  |  |  |  |
| https://inboxwarm.ai/blog/sender-score-guide | 4 | 8255 | 9 |  |  |  |  |
| https://inboxwarm.ai/blog/spam-trigger-words-list | 4 | 5043 | 6 |  |  |  |  |
| https://inboxwarm.ai/blog/why-cold-emails-go-to-spam | 4 | 3836 | 9 |  |  |  |  |
| https://inboxwarm.ai/blog/author/editorialteam-iw/page/3 | 5 | 235 | 2 |  |  |  |  |
| https://inboxwarm.ai/blog/author/editorialteam-iw/page/5 | 5 | 253 | 2 |  |  |  |  |
| https://inboxwarm.ai/blog/author/editorialteam-iw/page/4 | 6 | 234 | 2 |  |  |  |  |
| https://inboxwarm.ai/ar |  | 2875 | 24 |  |  |  |  |
| https://inboxwarm.ai/ar/about |  | 445 | 24 |  |  |  |  |
| https://inboxwarm.ai/ar/api |  | 1417 | 24 |  |  |  |  |
| https://inboxwarm.ai/ar/api/docs |  | 2891 | 24 |  |  |  |  |
| https://inboxwarm.ai/ar/email-deliverability |  | 522 | 24 |  |  |  |  |
| https://inboxwarm.ai/ar/email-infrastructure |  | 554 | 24 |  |  |  |  |
| https://inboxwarm.ai/ar/email-warmup |  | 1444 | 24 |  |  |  |  |
| https://inboxwarm.ai/ar/email-warmup/gmail |  | 1045 | 24 |  |  |  |  |
| https://inboxwarm.ai/ar/email-warmup/mailgun |  | 832 | 24 |  |  |  |  |
| https://inboxwarm.ai/ar/email-warmup/outlook |  | 903 | 24 |  |  |  |  |
| https://inboxwarm.ai/ar/email-warmup/sendgrid |  | 1011 | 24 |  |  |  |  |
| https://inboxwarm.ai/ar/email-warmup/smtp |  | 799 | 24 |  |  |  |  |
| https://inboxwarm.ai/ar/pricing |  | 1205 | 24 |  |  |  |  |
| https://inboxwarm.ai/ar/tools/bimi-checker |  | 872 | 24 |  |  |  |  |
| https://inboxwarm.ai/ar/tools/cname-checker |  | 932 | 24 |  |  |  |  |
| https://inboxwarm.ai/ar/tools/dkim-checker |  | 941 | 24 |  |  |  |  |
| https://inboxwarm.ai/ar/tools/dmarc-checker |  | 1001 | 24 |  |  |  |  |
| https://inboxwarm.ai/ar/tools/email-score |  | 380 | 24 |  |  |  |  |
| https://inboxwarm.ai/ar/tools/esp-checker |  | 827 | 24 |  |  |  |  |
| https://inboxwarm.ai/ar/tools/mta-sts-checker |  | 912 | 24 |  |  |  |  |
| https://inboxwarm.ai/ar/tools/spam-test |  | 918 | 24 |  |  |  |  |
| https://inboxwarm.ai/ar/tools/spf-checker |  | 814 | 24 |  |  |  |  |
| https://inboxwarm.ai/ar/tools/spf-generator |  | 879 | 24 |  |  |  |  |
| https://inboxwarm.ai/ar/tools/ssl-checker |  | 857 | 24 |  |  |  |  |
| https://inboxwarm.ai/ar/tools/whois-checker |  | 848 | 24 |  |  |  |  |
| https://inboxwarm.ai/de |  | 2551 | 24 |  |  |  |  |
| https://inboxwarm.ai/de/about |  | 484 | 24 |  |  |  |  |
| https://inboxwarm.ai/de/api |  | 1253 | 24 |  |  |  |  |
| https://inboxwarm.ai/de/api/docs |  | 2598 | 24 |  |  |  |  |
| https://inboxwarm.ai/de/email-deliverability |  | 441 | 24 |  |  |  |  |
| https://inboxwarm.ai/de/email-infrastructure |  | 474 | 24 |  |  |  |  |
| https://inboxwarm.ai/de/email-warmup |  | 1289 | 24 |  |  |  |  |
| https://inboxwarm.ai/de/email-warmup/gmail |  | 934 | 24 |  |  |  |  |
| https://inboxwarm.ai/de/email-warmup/mailgun |  | 755 | 24 |  |  |  |  |
| https://inboxwarm.ai/de/email-warmup/outlook |  | 836 | 24 |  |  |  |  |
| https://inboxwarm.ai/de/email-warmup/sendgrid |  | 895 | 24 |  |  |  |  |
| https://inboxwarm.ai/de/email-warmup/smtp |  | 736 | 24 |  |  |  |  |
| https://inboxwarm.ai/de/pricing |  | 1092 | 24 |  |  |  |  |
| https://inboxwarm.ai/de/tools/bimi-checker |  | 851 | 24 |  |  |  |  |
| https://inboxwarm.ai/de/tools/cname-checker |  | 891 | 24 |  |  |  |  |
| https://inboxwarm.ai/de/tools/dkim-checker |  | 925 | 24 |  |  |  |  |
| https://inboxwarm.ai/de/tools/dmarc-checker |  | 998 | 24 |  |  |  |  |
| https://inboxwarm.ai/de/tools/dmarc-generator |  | 1058 | 24 |  |  |  |  |
| https://inboxwarm.ai/de/tools/email-score |  | 379 | 24 |  |  |  |  |
| https://inboxwarm.ai/de/tools/esp-checker |  | 790 | 24 |  |  |  |  |
| https://inboxwarm.ai/de/tools/spam-test |  | 854 | 24 |  |  |  |  |
| https://inboxwarm.ai/de/tools/spf-checker |  | 807 | 24 |  |  |  |  |
| https://inboxwarm.ai/de/tools/spf-generator |  | 882 | 24 |  |  |  |  |
| https://inboxwarm.ai/de/tools/ssl-checker |  | 789 | 24 |  |  |  |  |
| https://inboxwarm.ai/de/tools/whois-checker |  | 761 | 24 |  |  |  |  |
| https://inboxwarm.ai/es |  | 3328 | 24 |  |  |  |  |
| https://inboxwarm.ai/es/about |  | 552 | 24 |  |  |  |  |
| https://inboxwarm.ai/es/api |  | 1567 | 24 |  |  |  |  |
| https://inboxwarm.ai/es/api/docs |  | 3202 | 24 |  |  |  |  |
| https://inboxwarm.ai/es/email-deliverability |  | 618 | 24 |  |  |  |  |
| https://inboxwarm.ai/es/email-infrastructure |  | 623 | 24 |  |  |  |  |
| https://inboxwarm.ai/es/email-warmup |  | 1652 | 24 |  |  |  |  |
| https://inboxwarm.ai/es/email-warmup/gmail |  | 1246 | 24 |  |  |  |  |
| https://inboxwarm.ai/es/email-warmup/mailgun |  | 1012 | 24 |  |  |  |  |
| https://inboxwarm.ai/es/email-warmup/outlook |  | 1081 | 24 |  |  |  |  |
| https://inboxwarm.ai/es/email-warmup/smtp |  | 920 | 24 |  |  |  |  |
| https://inboxwarm.ai/es/pricing |  | 1288 | 24 |  |  |  |  |
| https://inboxwarm.ai/es/tools/bimi-checker |  | 976 | 24 |  |  |  |  |
| https://inboxwarm.ai/es/tools/cname-checker |  | 1006 | 24 |  |  |  |  |
| https://inboxwarm.ai/es/tools/dkim-checker |  | 935 | 24 |  |  |  |  |
| https://inboxwarm.ai/es/tools/dmarc-checker |  | 1003 | 24 |  |  |  |  |
| https://inboxwarm.ai/es/tools/dmarc-generator |  | 1049 | 24 |  |  |  |  |
| https://inboxwarm.ai/es/tools/email-score |  | 379 | 24 |  |  |  |  |
| https://inboxwarm.ai/es/tools/esp-checker |  | 910 | 24 |  |  |  |  |
| https://inboxwarm.ai/es/tools/mta-sts-checker |  | 1086 | 24 |  |  |  |  |
| https://inboxwarm.ai/es/tools/spam-test |  | 1069 | 24 |  |  |  |  |
| https://inboxwarm.ai/es/tools/spf-checker |  | 734 | 24 |  |  |  |  |
| https://inboxwarm.ai/es/tools/spf-generator |  | 843 | 24 |  |  |  |  |
| https://inboxwarm.ai/es/tools/ssl-checker |  | 969 | 24 |  |  |  |  |
| https://inboxwarm.ai/es/tools/whois-checker |  | 944 | 24 |  |  |  |  |
| https://inboxwarm.ai/fr |  | 3202 | 23 |  |  |  |  |
| https://inboxwarm.ai/fr/about |  | 555 | 23 |  |  |  |  |
| https://inboxwarm.ai/fr/api |  | 1540 | 23 |  |  |  |  |
| https://inboxwarm.ai/fr/api/docs |  | 3230 | 23 |  |  |  |  |
| https://inboxwarm.ai/fr/email-deliverability |  | 615 | 23 |  |  |  |  |
| https://inboxwarm.ai/fr/email-infrastructure |  | 608 | 23 |  |  |  |  |
| https://inboxwarm.ai/fr/email-warmup |  | 1633 | 23 |  |  |  |  |
| https://inboxwarm.ai/fr/email-warmup/gmail |  | 1208 | 23 |  |  |  |  |
| https://inboxwarm.ai/fr/email-warmup/mailgun |  | 976 | 23 |  |  |  |  |
| https://inboxwarm.ai/fr/email-warmup/outlook |  | 1049 | 23 |  |  |  |  |
| https://inboxwarm.ai/fr/email-warmup/smtp |  | 927 | 23 |  |  |  |  |
| https://inboxwarm.ai/fr/pricing |  | 1355 | 23 |  |  |  |  |
| https://inboxwarm.ai/fr/tools/bimi-checker |  | 947 | 23 |  |  |  |  |
| https://inboxwarm.ai/fr/tools/cname-checker |  | 1026 | 23 |  |  |  |  |
| https://inboxwarm.ai/fr/tools/dkim-checker |  | 960 | 23 |  |  |  |  |
| https://inboxwarm.ai/fr/tools/dmarc-checker |  | 1095 | 23 |  |  |  |  |
| https://inboxwarm.ai/fr/tools/email-score |  | 379 | 23 |  |  |  |  |
| https://inboxwarm.ai/fr/tools/esp-checker |  | 937 | 23 |  |  |  |  |
| https://inboxwarm.ai/fr/tools/mta-sts-checker |  | 1066 | 23 |  |  |  |  |
| https://inboxwarm.ai/fr/tools/spam-test |  | 1050 | 23 |  |  |  |  |
| https://inboxwarm.ai/fr/tools/spf-checker |  | 780 | 23 |  |  |  |  |
| https://inboxwarm.ai/fr/tools/spf-generator |  | 878 | 23 |  |  |  |  |
| https://inboxwarm.ai/fr/tools/ssl-checker |  | 965 | 23 |  |  |  |  |
| https://inboxwarm.ai/fr/tools/whois-checker |  | 975 | 23 |  |  |  |  |
| https://inboxwarm.ai/ja |  | 378 | 25 |  |  |  |  |
| https://inboxwarm.ai/ja/about |  | 43 | 25 |  |  |  |  |
| https://inboxwarm.ai/ja/api |  | 212 | 25 |  |  |  |  |
| https://inboxwarm.ai/ja/api/docs |  | 1829 | 25 |  |  |  |  |
| https://inboxwarm.ai/ja/email-deliverability |  | 72 | 25 |  |  |  |  |
| https://inboxwarm.ai/ja/email-infrastructure |  | 66 | 25 |  |  |  |  |
| https://inboxwarm.ai/ja/email-warmup |  | 195 | 25 |  |  |  |  |
| https://inboxwarm.ai/ja/email-warmup/gmail |  | 173 | 25 |  |  |  |  |
| https://inboxwarm.ai/ja/email-warmup/mailgun |  | 147 | 25 |  |  |  |  |
| https://inboxwarm.ai/ja/email-warmup/outlook |  | 192 | 25 |  |  |  |  |
| https://inboxwarm.ai/ja/email-warmup/sendgrid |  | 167 | 25 |  |  |  |  |
| https://inboxwarm.ai/ja/email-warmup/smtp |  | 113 | 25 |  |  |  |  |
| https://inboxwarm.ai/ja/pricing |  | 306 | 25 |  |  |  |  |
| https://inboxwarm.ai/ja/tools/bimi-checker |  | 359 | 25 |  |  |  |  |
| https://inboxwarm.ai/ja/tools/cname-checker |  | 116 | 25 |  |  |  |  |
| https://inboxwarm.ai/ja/tools/dkim-checker |  | 225 | 25 |  |  |  |  |
| https://inboxwarm.ai/ja/tools/dmarc-checker |  | 198 | 25 |  |  |  |  |
| https://inboxwarm.ai/ja/tools/dmarc-generator |  | 237 | 25 |  |  |  |  |
| https://inboxwarm.ai/ja/tools/email-score |  | 378 | 25 |  |  |  |  |
| https://inboxwarm.ai/ja/tools/esp-checker |  | 156 | 25 |  |  |  |  |
| https://inboxwarm.ai/ja/tools/mta-sts-checker |  | 329 | 25 |  |  |  |  |
| https://inboxwarm.ai/ja/tools/spam-test |  | 66 | 25 |  |  |  |  |
| https://inboxwarm.ai/ja/tools/spf-checker |  | 150 | 25 |  |  |  |  |
| https://inboxwarm.ai/ja/tools/spf-generator |  | 183 | 25 |  |  |  |  |
| https://inboxwarm.ai/ja/tools/ssl-checker |  | 129 | 25 |  |  |  |  |
| https://inboxwarm.ai/ja/tools/whois-checker |  | 111 | 25 |  |  |  |  |
| https://inboxwarm.ai/ko |  | 2230 | 25 |  |  |  |  |
| https://inboxwarm.ai/ko/about |  | 388 | 25 |  |  |  |  |
| https://inboxwarm.ai/ko/api |  | 1099 | 25 |  |  |  |  |
| https://inboxwarm.ai/ko/api/docs |  | 2616 | 25 |  |  |  |  |
| https://inboxwarm.ai/ko/email-deliverability |  | 423 | 25 |  |  |  |  |
| https://inboxwarm.ai/ko/email-infrastructure |  | 428 | 25 |  |  |  |  |
| https://inboxwarm.ai/ko/email-warmup |  | 1134 | 25 |  |  |  |  |
| https://inboxwarm.ai/ko/email-warmup/gmail |  | 852 | 25 |  |  |  |  |
| https://inboxwarm.ai/ko/email-warmup/mailgun |  | 679 | 25 |  |  |  |  |
| https://inboxwarm.ai/ko/email-warmup/outlook |  | 764 | 25 |  |  |  |  |
| https://inboxwarm.ai/ko/email-warmup/sendgrid |  | 798 | 25 |  |  |  |  |
| https://inboxwarm.ai/ko/email-warmup/smtp |  | 654 | 25 |  |  |  |  |
| https://inboxwarm.ai/ko/pricing |  | 963 | 25 |  |  |  |  |
| https://inboxwarm.ai/ko/tools/bimi-checker |  | 681 | 25 |  |  |  |  |
| https://inboxwarm.ai/ko/tools/cname-checker |  | 691 | 25 |  |  |  |  |
| https://inboxwarm.ai/ko/tools/dkim-checker |  | 682 | 25 |  |  |  |  |
| https://inboxwarm.ai/ko/tools/dmarc-checker |  | 792 | 25 |  |  |  |  |
| https://inboxwarm.ai/ko/tools/dmarc-generator |  | 811 | 25 |  |  |  |  |
| https://inboxwarm.ai/ko/tools/email-score |  | 382 | 25 |  |  |  |  |
| https://inboxwarm.ai/ko/tools/esp-checker |  | 657 | 25 |  |  |  |  |
| https://inboxwarm.ai/ko/tools/mta-sts-checker |  | 738 | 25 |  |  |  |  |
| https://inboxwarm.ai/ko/tools/spam-test |  | 708 | 25 |  |  |  |  |
| https://inboxwarm.ai/ko/tools/spf-checker |  | 567 | 25 |  |  |  |  |
| https://inboxwarm.ai/ko/tools/spf-generator |  | 632 | 25 |  |  |  |  |
| https://inboxwarm.ai/ko/tools/ssl-checker |  | 653 | 25 |  |  |  |  |
| https://inboxwarm.ai/ko/tools/whois-checker |  | 651 | 25 |  |  |  |  |
| https://inboxwarm.ai/pt |  | 3265 | 24 |  |  |  |  |
| https://inboxwarm.ai/pt/about |  | 543 | 24 |  |  |  |  |
| https://inboxwarm.ai/pt/api |  | 1594 | 24 |  |  |  |  |
| https://inboxwarm.ai/pt/api/docs |  | 3082 | 24 |  |  |  |  |
| https://inboxwarm.ai/pt/email-deliverability |  | 601 | 24 |  |  |  |  |
| https://inboxwarm.ai/pt/email-infrastructure |  | 607 | 24 |  |  |  |  |
| https://inboxwarm.ai/pt/email-warmup |  | 1639 | 24 |  |  |  |  |
| https://inboxwarm.ai/pt/email-warmup/gmail |  | 1249 | 24 |  |  |  |  |
| https://inboxwarm.ai/pt/email-warmup/mailgun |  | 1015 | 24 |  |  |  |  |
| https://inboxwarm.ai/pt/email-warmup/outlook |  | 1102 | 24 |  |  |  |  |
| https://inboxwarm.ai/pt/email-warmup/smtp |  | 909 | 24 |  |  |  |  |
| https://inboxwarm.ai/pt/pricing |  | 1311 | 24 |  |  |  |  |
| https://inboxwarm.ai/pt/tools/bimi-checker |  | 965 | 24 |  |  |  |  |
| https://inboxwarm.ai/pt/tools/cname-checker |  | 1001 | 24 |  |  |  |  |
| https://inboxwarm.ai/pt/tools/dkim-checker |  | 905 | 24 |  |  |  |  |
| https://inboxwarm.ai/pt/tools/dmarc-checker |  | 978 | 24 |  |  |  |  |
| https://inboxwarm.ai/pt/tools/dmarc-generator |  | 1013 | 24 |  |  |  |  |
| https://inboxwarm.ai/pt/tools/email-score |  | 378 | 24 |  |  |  |  |
| https://inboxwarm.ai/pt/tools/esp-checker |  | 912 | 24 |  |  |  |  |
| https://inboxwarm.ai/pt/tools/mta-sts-checker |  | 1036 | 24 |  |  |  |  |
| https://inboxwarm.ai/pt/tools/spam-test |  | 1050 | 24 |  |  |  |  |
| https://inboxwarm.ai/pt/tools/spf-checker |  | 712 | 24 |  |  |  |  |
| https://inboxwarm.ai/pt/tools/spf-generator |  | 821 | 24 |  |  |  |  |
| https://inboxwarm.ai/pt/tools/ssl-checker |  | 926 | 24 |  |  |  |  |
| https://inboxwarm.ai/pt/tools/whois-checker |  | 926 | 24 |  |  |  |  |
| https://inboxwarm.ai/ru |  | 2591 | 22 |  |  |  |  |
| https://inboxwarm.ai/ru/about |  | 416 | 22 |  |  |  |  |
| https://inboxwarm.ai/ru/api |  | 1263 | 22 |  |  |  |  |
| https://inboxwarm.ai/ru/api/docs |  | 2880 | 22 |  |  |  |  |
| https://inboxwarm.ai/ru/email-deliverability |  | 490 | 22 |  |  |  |  |
| https://inboxwarm.ai/ru/email-infrastructure |  | 490 | 22 |  |  |  |  |
| https://inboxwarm.ai/ru/email-warmup |  | 1310 | 22 |  |  |  |  |
| https://inboxwarm.ai/ru/email-warmup/gmail |  | 961 | 22 |  |  |  |  |
| https://inboxwarm.ai/ru/email-warmup/mailgun |  | 762 | 22 |  |  |  |  |
| https://inboxwarm.ai/ru/email-warmup/outlook |  | 862 | 22 |  |  |  |  |
| https://inboxwarm.ai/ru/email-warmup/smtp |  | 718 | 22 |  |  |  |  |
| https://inboxwarm.ai/ru/pricing |  | 1144 | 22 |  |  |  |  |
| https://inboxwarm.ai/ru/tools/bimi-checker |  | 803 | 22 |  |  |  |  |
| https://inboxwarm.ai/ru/tools/cname-checker |  | 792 | 22 |  |  |  |  |
| https://inboxwarm.ai/ru/tools/dkim-checker |  | 760 | 22 |  |  |  |  |
| https://inboxwarm.ai/ru/tools/dmarc-checker |  | 827 | 22 |  |  |  |  |
| https://inboxwarm.ai/ru/tools/email-score |  | 381 | 22 |  |  |  |  |
| https://inboxwarm.ai/ru/tools/esp-checker |  | 719 | 22 |  |  |  |  |
| https://inboxwarm.ai/ru/tools/spam-test |  | 835 | 22 |  |  |  |  |
| https://inboxwarm.ai/ru/tools/spf-checker |  | 591 | 22 |  |  |  |  |
| https://inboxwarm.ai/ru/tools/spf-generator |  | 658 | 22 |  |  |  |  |
| https://inboxwarm.ai/ru/tools/ssl-checker |  | 740 | 22 |  |  |  |  |
| https://inboxwarm.ai/ru/tools/whois-checker |  | 748 | 22 |  |  |  |  |
| https://inboxwarm.ai/zh |  | 838 | 24 |  |  |  |  |
| https://inboxwarm.ai/zh/about |  | 97 | 24 |  |  |  |  |
| https://inboxwarm.ai/zh/api |  | 571 | 24 |  |  |  |  |
| https://inboxwarm.ai/zh/api/docs |  | 1979 | 24 |  |  |  |  |
| https://inboxwarm.ai/zh/email-deliverability |  | 131 | 24 |  |  |  |  |
| https://inboxwarm.ai/zh/email-infrastructure |  | 159 | 24 |  |  |  |  |
| https://inboxwarm.ai/zh/email-warmup |  | 415 | 24 |  |  |  |  |
| https://inboxwarm.ai/zh/email-warmup/gmail |  | 364 | 24 |  |  |  |  |
| https://inboxwarm.ai/zh/email-warmup/mailgun |  | 350 | 24 |  |  |  |  |
| https://inboxwarm.ai/zh/email-warmup/outlook |  | 410 | 24 |  |  |  |  |
| https://inboxwarm.ai/zh/email-warmup/smtp |  | 304 | 24 |  |  |  |  |
| https://inboxwarm.ai/zh/pricing |  | 468 | 24 |  |  |  |  |
| https://inboxwarm.ai/zh/tools/bimi-checker |  | 336 | 24 |  |  |  |  |
| https://inboxwarm.ai/zh/tools/cname-checker |  | 353 | 24 |  |  |  |  |
| https://inboxwarm.ai/zh/tools/dkim-checker |  | 342 | 24 |  |  |  |  |
| https://inboxwarm.ai/zh/tools/dmarc-checker |  | 416 | 24 |  |  |  |  |
| https://inboxwarm.ai/zh/tools/dmarc-generator |  | 447 | 24 |  |  |  |  |
| https://inboxwarm.ai/zh/tools/email-score |  | 377 | 24 |  |  |  |  |
| https://inboxwarm.ai/zh/tools/esp-checker |  | 298 | 24 |  |  |  |  |
| https://inboxwarm.ai/zh/tools/mta-sts-checker |  | 339 | 24 |  |  |  |  |
| https://inboxwarm.ai/zh/tools/spam-test |  | 109 | 24 |  |  |  |  |
| https://inboxwarm.ai/zh/tools/spf-checker |  | 313 | 24 |  |  |  |  |
| https://inboxwarm.ai/zh/tools/spf-generator |  | 352 | 24 |  |  |  |  |
| https://inboxwarm.ai/zh/tools/ssl-checker |  | 245 | 24 |  |  |  |  |
| https://inboxwarm.ai/zh/tools/whois-checker |  | 221 | 24 |  |  |  |  |

## Method and limits

- Area score: 100 minus, per finding, severity amount (critical 25, high 12, medium 6, low 2) × (0.5 + 0.5 × share of pages affected). Content and AI readiness blend 70% Jev judgment with 30% rules. Performance blends 50% Lighthouse mobile with 50% crawl observations.
- Overall: weighted mean of scored areas; unscored areas are excluded, never zero.
- Impact: severity weight × (0.6 + 0.4 × reach) × (0.6 + 0.8 × highest Jev importance of affected pages), scaled to 100.
- Jev answers are decisive at confidence 0.80 (Choice, Score) or P(yes) at least 0.80 or at most 0.20 (Noul). Others are flagged to verify.
- Jev: model n/a, 0 requests, 0 input tokens, 0 failed, cost $0.0000.
- No Search Console, analytics, backlink or keyword data was used (run with --full for DataForSEO).
- Scores rank work; they do not predict rankings or traffic.

_Generated by jev-seo 0.1.1._
