# Digest: inboxwarm.ai
Audited 2026-11-25T13:23:43+00:00. Pages fetched: 464; HTML pages: 461.
Overall 88 (B). Crawl and indexing 68, On-page 94, Content quality n/a, Links and architecture 90, Structured data and sharing 95, AI search readiness 100, Performance 94, Security and trust 100, Search visibility and authority n/a
Caps: none. Completeness: {'categories_scored': 7, 'categories_total': 9, 'jev': False, 'jev_pages_not_judged': 0, 'pagespeed': False, 'dataforseo': False}
PARTIAL AUDIT: Jev judgments unavailable, so content quality was not assessed; PageSpeed Insights unavailable, so performance used crawl timings only. Say so in the narrative.
Homepage: title='Email Warmup Tool & Inbox Warmup Service | InboxWarm'; h1=['Email Warmup Tool & Inbox Warmup Service']; meta='Automatic email warmup for Gmail, Outlook, Amazon SES, SendGrid, Mailgun and any SMTP inbox. Real seed inboxes, AI replies, spam recovery. 7-day free trial.'

## Actions (id, priority, impact, effort, count, title, evidence, review flags)
- JEV-001 P1 impact 100 effort 1 [rule/crawl/high] Pages excluded from search with noindex x14: 14 pages carry noindex
  URLs: /privacy-policy, /terms-of-use, /blog/category/cold-email-templates/page/2, /blog/category/cold-email-templates/page/4, /blog/category/email-deliverability/page/2, /blog/category/email-warm-up/page/2, /blog/category/cold-email-templates/page/3, /blog/author/maryam/page/2 +6 more
- JEV-002 P1 impact 98 effort 2 [rule/crawl/high] Pages returning HTTP errors x1: 404
  URLs: /blog/Email%20Warm-Up%20API:%20Programmatic%20Warm-Up%20for%20Developers
- JEV-003 P1 impact 98 effort 2 [rule/links/high] Internal links pointing to broken URLs x1: 1 broken targets: 404 https://inboxwarm.ai/blog/Email%20Warm-Up%20API:%20Programmatic%20Warm-Up%20for%20Developers (linked from /blog/email-warm-up-api)
  URLs: /blog/email-warm-up-api
- JEV-004 P2 impact 82 effort 1 [rule/crawl/medium] www and non-www both serve the site x1: www.inboxwarm.ai answers without redirecting to the preferred host
  URLs: www.inboxwarm.ai/
- JEV-005 P2 impact 82 effort 2 [rule/crawl/medium] Missing pages return HTTP 200 (soft 404) x1: A random nonexistent URL returned HTTP 200
  URLs: /jevseo-…-not-found
- JEV-006 P2 impact 55 effort 3 [rule/performance/medium] Slow server response (TTFB above 0.8 s) x84: /blog/category/cold-email-outreach: 1263 ms; /blog/category/cold-email-templates/sales: 1235 ms; /blog/category/cold-email-templates/lead-generation: 1228 ms; /blog/category/cold-email-templates/networking: 1264 ms; /blog/category/cold-email-templates/follow-up: 1201 ms; /blog/follow-up-email-after-free-trial-ends: 1296 ms
  URLs: /blog/category/cold-email-outreach, /blog/category/cold-email-templates/sales, /blog/category/cold-email-templates/lead-generation, /blog/category/cold-email-templates/networking, /blog/category/cold-email-templates/follow-up, /blog/follow-up-email-after-free-trial-ends, /blog/follow-up-email-after-sending-information, /blog/follow-up-email-after-sending-pricing +76 more
- JEV-007 P2 impact 50 effort 1 [rule/onpage/medium] Duplicate titles across pages x19: 6 titles shared by several pages
  URLs: /blog/author/editorialteam-iw, /blog/author/editorialteam-iw/page/2, /blog/author/editorialteam-iw/page/3, /blog/author/editorialteam-iw/page/4, /blog/author/editorialteam-iw/page/5, /blog/author/editorialteam-iw/page/6, /blog/author/maryam, /blog/author/maryam/page/2 +11 more
- JEV-008 P2 impact 50 effort 3 [rule/content/medium] Pages with very little main content x12: /zh/about: 97 words; /ja/about: 43 words; /zh/tools/spam-test: 109 words; /ja/tools/spam-test: 66 words; /ja/email-warmup/smtp: 113 words; /ja/tools/ssl-checker: 129 words; /ja/tools/whois-checker: 111 words; /ja/tools/cname-checker: 116 words
  URLs: /zh/about, /ja/about, /zh/tools/spam-test, /ja/tools/spam-test, /ja/email-warmup/smtp, /ja/tools/ssl-checker, /ja/tools/whois-checker, /ja/tools/cname-checker +4 more
- JEV-009 P2 impact 49 effort 1 [rule/crawl/medium] Redirect chains (more than one hop) x1: https://inboxwarm.ai/email-warm-up (2 hops)
  URLs: /email-warm-up
- JEV-010 P2 impact 49 effort 1 [rule/crawl/medium] Canonical points to a different URL x1: https://inboxwarm.ai/pricing?billing=yearly&inboxes=10 -> https://inboxwarm.ai/pricing
  URLs: /pricing
- JEV-011 P2 impact 49 effort 2 [rule/content/medium] Pages with identical main text x2: 1 group of pages with identical main text
  URLs: /pricing, /pricing
- JEV-012 P2 impact 49 effort 2 [rule/structured/medium] hreflang annotations incomplete x1: 1 page with hreflang but no self-reference
  URLs: /pricing
- JEV-013 P3 impact 24 effort 2 [rule/performance/low] Very large HTML documents (over 500 KB) x331: /: 704 KB; /pricing: 584 KB; /pricing: 584 KB; /api: 607 KB; /email-warmup/gmail: 585 KB; /email-warmup/outlook: 581 KB
  URLs: /, /pricing, /pricing, /api, /email-warmup/gmail, /email-warmup/outlook, /email-warmup/amazon-ses, /email-warmup/sendgrid +323 more
- JEV-014 P3 impact 19 effort 1 [rule/crawl/low] Indexable pages missing from the sitemap x118: 118 crawled indexable pages are not listed
  URLs: /blog, /blog/category/cold-email-templates, /blog/category/email-deliverability, /blog/category/email-warm-up, /blog/category/cold-email-outreach, /blog/category/authentication, /blog/category/cold-email-templates/sales, /blog/category/cold-email-templates/lead-generation +110 more
- JEV-015 P3 impact 19 effort 1 [rule/links/low] Internal links that go through a redirect x109: / links to /email-warm-up (redirects to /email-warmup); /pricing links to /email-warm-up (redirects to /email-warmup); /pricing links to /email-warm-up (redirects to /email-warmup); /api links to /email-warm-up (redirects to /email-warmup); /email-warmup/gmail links to /email-warm-up (redirects to /email-warmup); and 104 more
  URLs: /, /about, /api, /api/docs, /blog/best-email-warm-up-tools, /blog/warmbox-alternatives, /cold-email-roi-calculator, /compare/inboxwarm-vs-instantly +101 more
- JEV-016 P3 impact 18 effort 1 [rule/onpage/low] Heading levels skipped x60: 60 pages skip a heading level
  URLs: /blog, /blog/google-workspace-spf-record-setup, /blog/google-yahoo-sender-requirements, /blog/how-to-set-up-dkim-microsoft-365, /blog/smtp-server-warm-up-guide, /blog/how-long-does-email-warm-up-take, /blog/smtp-test-passed-but-emails-still-go-to-spam, /blog/how-to-get-off-an-email-blacklist +52 more
- JEV-017 P3 impact 18 effort 1 [rule/structured/low] Structured data missing properties Google requires for rich results x50: SoftwareApplication on / lacks offers.price, aggregateRating or review; SoftwareApplication on /api lacks offers.price, aggregateRating or review; SoftwareApplication on /email-warmup lacks offers.price, aggregateRating or review; SoftwareApplication on /email-deliverability lacks offers.price, aggregateRating or review; SoftwareApplication on /email-infrastructure lacks offers.price, aggregateRating or review; SoftwareApplication on /zh lacks offers.price, aggregateRating or review; and 44 more
  URLs: /, /api, /ar, /ar/api, /ar/email-deliverability, /ar/email-infrastructure, /ar/email-warmup, /de +42 more
- JEV-018 P3 impact 17 effort 1 [rule/crawl/low] Pages without a canonical link x12: 12 of 461 pages
  URLs: /blog/category/cold-email-templates/page/2, /blog/category/cold-email-templates/page/4, /blog/category/email-deliverability/page/2, /blog/category/email-warm-up/page/2, /blog/category/cold-email-templates/page/3, /blog/author/maryam/page/2, /blog/author/maryam/page/3, /blog/author/editorialteam-iw/page/2 +4 more
- JEV-019 P3 impact 17 effort 1 [rule/onpage/low] Very short or very long titles x28: 68 chars; 69 chars; 68 chars; 78 chars; 68 chars; 67 chars; 67 chars; 70 chars
  URLs: /tools/email-score, /blog/google-workspace-spf-record-setup, /blog/google-workspace-dmarc-setup, /blog/google-yahoo-sender-requirements, /blog/best-email-deliverability-tools, /blog/how-to-check-domain-reputation, /blog/stop-emails-going-to-spam, /blog/email-spam-score +20 more
- JEV-020 P3 impact 17 effort 1 [rule/onpage/low] Duplicate meta descriptions x19: 6 descriptions shared by several pages
  URLs: /blog/author/editorialteam-iw, /blog/author/editorialteam-iw/page/2, /blog/author/editorialteam-iw/page/3, /blog/author/editorialteam-iw/page/4, /blog/author/editorialteam-iw/page/5, /blog/author/editorialteam-iw/page/6, /blog/author/maryam, /blog/author/maryam/page/2 +11 more
- JEV-021 P3 impact 17 effort 1 [rule/structured/low] Open Graph title or image missing x14: 14 pages lack og:title or og:image
  URLs: /blog/category/cold-email-templates, /blog/category/email-deliverability, /blog/category/email-warm-up, /blog/category/cold-email-outreach, /blog/category/authentication, /blog/category/cold-email-templates/sales, /blog/category/cold-email-templates/lead-generation, /blog/category/cold-email-templates/networking +6 more
- JEV-022 P3 impact 17 effort 2 [rule/links/low] Pages more than three clicks from the homepage x11: 11 pages deeper than three clicks
  URLs: /blog/category/cold-email-templates/page/3, /blog/why-cold-emails-go-to-spam, /blog/sender-score-guide, /blog/spam-trigger-words-list, /blog/author/maryam/page/2, /blog/author/maryam/page/3, /blog/author/editorialteam-iw/page/2, /blog/author/editorialteam-iw/page/6 +3 more
- JEV-023 P3 impact 16 effort 1 [rule/links/low] Internal links with generic anchor text x1: Anchors such as: READ MORE
  URLs: /blog
- JEV-024 P3 impact 16 effort 1 [rule/performance/low] Images without width and height x2: 2 images without explicit size
  URLs: /blog/author/maryam, /blog/author/editorialteam-iw
- JEV-025 P3 impact 16 effort 1 [rule/links/low] External links returning errors x2: 2 of 80 sampled outbound links
  URLs: documentation.mailgun.com/docs/mailgun/api-reference/openapi-final/ip-address-warmup, www.gong.io/wp-content/uploads/2023/01/11-Hyper-Persuasive-Sales-Email-Templates.pdf

Robots: search bots {'Googlebot': True, 'Bingbot': True}; AI bots checked (10): {'GPTBot': True, 'OAI-SearchBot': True, 'ChatGPT-User': True, 'ClaudeBot': True, 'Claude-SearchBot': True, 'PerplexityBot': True, 'Google-Extended': True, 'Applebot-Extended': True, 'CCBot': True, 'Bytespider': True}

## No issue detected by rule
robots_missing, robots_blocks_site, sitemap_missing, sitemap_errors, sitemap_bad_urls, canonical_broken, host_temporary_redirect, no_https, orphan_pages, js_dependent, title_missing, multiple_titles, meta_missing, h1_missing, h1_multiple, lang_missing, viewport_missing, images_alt, no_structured_data, jsonld_errors, ai_bots_blocked, llms_txt_missing, hsts_missing, security_headers, mixed_content, favicon_missing
- PSI mobile https://inboxwarm.ai/: HTTP 429
- PSI desktop https://inboxwarm.ai/: HTTP 429
- PSI mobile https://inboxwarm.ai/blog: HTTP 429
- PSI desktop https://inboxwarm.ai/blog: HTTP 429
- PSI mobile https://inboxwarm.ai/glossary: HTTP 429
- PSI desktop https://inboxwarm.ai/glossary: HTTP 429

Jev ledger: {'model_requested': 'jev-latest', 'model_returned': None, 'requests': 0, 'failed': 0, 'input_tokens': 0, 'output_tokens': 0, 'est_reserved_tokens': 0, 'skipped_budget': 0, 'errors': []}
