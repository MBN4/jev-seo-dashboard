# Digest: clustox.com
Audited 2026-11-25T13:29:15+00:00. Pages fetched: 732; HTML pages: 653.
Overall 92 (A). Crawl and indexing 84, On-page 90, Content quality n/a, Links and architecture 91, Structured data and sharing 98, AI search readiness 100, Performance 93, Security and trust 100, Search visibility and authority n/a
Caps: none. Completeness: {'categories_scored': 7, 'categories_total': 9, 'jev': False, 'jev_pages_not_judged': 0, 'pagespeed': False, 'dataforseo': False}
PARTIAL AUDIT: Jev judgments unavailable, so content quality was not assessed; PageSpeed Insights unavailable, so performance used crawl timings only. Say so in the narrative.
Homepage: title='AI-First Engineering Partner for Modern Businesses | Clustox'; h1=["Your AI-First Engineering Partner for What's Next"]; meta='Clustox is an AI-first engineering company helping global businesses build AI systems, modernize software, and scale secure cloud infrastructure since 2012.'

## Actions (id, priority, impact, effort, count, title, evidence, review flags)
- JEV-001 P1 impact 100 effort 1 [rule/crawl/high] Pages excluded from search with noindex x31: 31 pages carry noindex
  URLs: /privacy-policy, /fr/privacy-policy, /de/privacy-policy, /es/privacy-policy, /pt/privacy-policy, /blog/category/tech/page/2, /blog/category/tech/page/10, /blog/category/emerging-technologies/page/2 +23 more
- JEV-002 P1 impact 97 effort 2 [rule/crawl/high] Pages returning HTTP errors x1: 404
  URLs: /blog/services/devops-services
- JEV-003 P1 impact 97 effort 2 [rule/links/high] Internal links pointing to broken URLs x3: 3 broken targets: 404 https://www.clustox.com/services/devops-services%5C%5C%22 (linked from /blog/ai-agent-architecture-blueprint); 404 https://www.clustox.com/services/application-development%5C%5C%22 (linked from /blog/nodejs-vs-react); 404 https://www.clustox.com/product-strategy' (linked from /blog/what-is-minimum-viable-product-mvp)
  URLs: /blog/ai-agent-architecture-blueprint, /blog/nodejs-vs-react, /blog/what-is-minimum-viable-product-mvp
- JEV-004 P2 impact 59 effort 3 [rule/performance/medium] Slow server response (TTFB above 0.8 s) x212: /contact-us: 804 ms; /blog/category/tech: 1068 ms; /blog/category/emerging-technologies: 1188 ms; /blog/category/clustox-healthcare-advisory: 1790 ms; /blog/category/software-development: 1842 ms; /blog/category/cloud-devops: 1820 ms
  URLs: /contact-us, /blog/category/tech, /blog/category/emerging-technologies, /blog/category/clustox-healthcare-advisory, /blog/category/software-development, /blog/category/cloud-devops, /blog/category/startups, /blog/category/product-development +204 more
- JEV-005 P2 impact 50 effort 1 [rule/onpage/medium] Duplicate titles across pages x26: 9 titles shared by several pages
  URLs: /blog/category/cio-insights, /blog/category/cio-insights/page/2, /blog/category/cloud-devops, /blog/category/cloud-devops/page/2, /blog/category/clustox-healthcare-advisory, /blog/category/clustox-healthcare-advisory/page/2, /blog/category/clustox-healthcare-advisory/page/3, /blog/category/emerging-technologies +18 more
- JEV-006 P2 impact 49 effort 1 [rule/crawl/medium] Redirect chains (more than one hop) x3: https://clustox.com/blog (2 hops); https://www.clustox.com/services/devops-services%5C%5C%22 (2 hops); https://www.clustox.com/blog/services/devops-services (2 hops)
  URLs: clustox.com/blog, /services/devops-services%5C%5C%22, /blog/services/devops-services
- JEV-007 P2 impact 49 effort 1 [rule/onpage/medium] Pages without a meta description x5: 5 indexable pages
  URLs: /blog/author/maryam-farooq, /blog/author/fiza-shahid, /blog/author/anusha-hassan, /blog/author/asad-hanif, /blog/author/ayesha-irshad
- JEV-008 P3 impact 23 effort 1 [rule/onpage/low] Heading levels skipped x395: 395 pages skip a heading level
  URLs: /services/ai-strategy-consulting-services, /services/ai-poc-mvp-development, /services/mlops, /services/data-engineering-integration, /services/ai-agents-agentic-workflows, /services/intelligent-automation, /services/machine-learning, /services/data-analytics +387 more
- JEV-009 P3 impact 23 effort 1 [rule/performance/low] Images without width and height x392: 3432 images without explicit size
  URLs: /, /company, /services, /services/ai-engineering-pod, /services/ai-strategy-consulting-services, /services/ai-poc-mvp-development, /services/mlops, /services/data-engineering-integration +384 more
- JEV-010 P3 impact 20 effort 1 [rule/links/low] Internal links that go through a redirect x257: /blog links to clustox.com/ (redirects to /); /blog links to clustox.com/blog (redirects to /blog); /blog links to clustox.com/company (redirects to /company); /blog links to clustox.com/contact-us (redirects to /contact-us); /blog links to clustox.com/locations (redirects to /locations); and 19529 more
  URLs: /blog, /blog/5-root-causes-of-why-products-fail, /blog/advantages-of-using-docker-for-microservices, /blog/agentic-ai-dme-operations-guide, /blog/agentic-ai-for-enterprise, /blog/agentic-ai-vs-ai-agents-vs-generative-ai, /blog/agile-software-development, /blog/ai-agent-architecture-blueprint +249 more
- JEV-011 P3 impact 19 effort 1 [rule/onpage/low] Very short or very long titles x178: 71 chars; 90 chars; 72 chars; 66 chars; 70 chars; 71 chars; 71 chars; 70 chars
  URLs: /services/application-security-and-penetration-testing, /blog, /fr, /fr/services, /de/services, /es/services, /pt/services, /fr/services/ai-engineering-pod +170 more
- JEV-012 P3 impact 18 effort 2 [rule/links/low] Pages more than three clicks from the homepage x94: 94 pages deeper than three clicks
  URLs: /blog/what-is-minimum-viable-product-mvp, /blog/conversational-ai-in-healthcare, /blog/ehr-software-development, /blog/ai-trends-in-healthtech, /blog/explainable-ai-in-healthcare, /blog/medical-imaging-and-computer-vision, /blog/why-ai-pilots-stall-before-deployment, /blog/ehr-vs-emr-vs-phr +86 more
- JEV-013 P3 impact 18 effort 2 [rule/performance/low] Very large HTML documents (over 500 KB) x98: /: 553 KB; /services/aws-cloud-services: 492 KB; /fr: 564 KB; /de: 558 KB; /es: 561 KB; /pt: 560 KB
  URLs: /, /services/aws-cloud-services, /fr, /de, /es, /pt, /fr/solutions/supplychain-and-logistics, /de/solutions/supplychain-and-logistics +90 more
- JEV-014 P3 impact 17 effort 1 [rule/crawl/low] Pages without a canonical link x30: 30 of 653 pages
  URLs: /privacy-policy, /fr/privacy-policy, /de/privacy-policy, /es/privacy-policy, /pt/privacy-policy, /blog/category/tech/page/2, /blog/category/tech/page/10, /blog/category/emerging-technologies/page/2 +22 more
- JEV-015 P3 impact 17 effort 1 [rule/onpage/low] Duplicate meta descriptions x29: 10 descriptions shared by several pages
  URLs: /blog/author/editorial-team, /blog/author/editorial-team/page/10, /blog/author/editorial-team/page/2, /blog/category/cio-insights, /blog/category/cio-insights/page/2, /blog/category/cloud-devops, /blog/category/cloud-devops/page/2, /blog/category/clustox-healthcare-advisory +21 more
- JEV-016 P3 impact 16 effort 1 [rule/structured/low] Structured data missing properties Google requires for rich results x7: SoftwareApplication on /blog/saas-vs-custom-software lacks offers.price, aggregateRating or review; SoftwareApplication on /blog/aws-compliance-standards lacks offers.price, aggregateRating or review; SoftwareApplication on /blog/enterprise-app-development-challenges-solutions lacks offers.price, aggregateRating or review; SoftwareApplication on /blog/notion-vs-custom-knowledge-base lacks offers.price, aggregateRating or review; SoftwareApplication on /blog/cost-to-build-a-marketplace-like-amazon lacks offers.price, aggregateRating or review; SoftwareApplication on /blog/cost-to-build-analytics-software lacks offers.price, aggregateRating or review; and 1 more
  URLs: /ai-commerce, /blog/aws-compliance-standards, /blog/cost-to-build-a-marketplace-like-amazon, /blog/cost-to-build-analytics-software, /blog/enterprise-app-development-challenges-solutions, /blog/notion-vs-custom-knowledge-base, /blog/saas-vs-custom-software
- JEV-017 P3 impact 16 effort 1 [rule/structured/low] Open Graph title or image missing x17: 17 pages lack og:title or og:image
  URLs: /blog, /blog/category/tech, /blog/category/emerging-technologies, /blog/category/clustox-healthcare-advisory, /blog/category/software-development, /blog/category/cloud-devops, /blog/category/startups, /blog/category/product-development +9 more

Robots: search bots {'Googlebot': True, 'Bingbot': True}; AI bots checked (10): {'GPTBot': True, 'OAI-SearchBot': True, 'ChatGPT-User': True, 'ClaudeBot': True, 'Claude-SearchBot': True, 'PerplexityBot': True, 'Google-Extended': True, 'Applebot-Extended': True, 'CCBot': True, 'Bytespider': True}

## No issue detected by rule
robots_missing, robots_blocks_site, sitemap_missing, sitemap_errors, sitemap_bad_urls, not_in_sitemap, canonical_elsewhere, canonical_broken, soft_404, host_temporary_redirect, host_variant, no_https, orphan_pages, js_dependent, title_missing, multiple_titles, h1_missing, h1_multiple, lang_missing, viewport_missing, thin_content, duplicate_content, images_alt, no_structured_data, jsonld_errors, hreflang_issues, ai_bots_blocked, llms_txt_missing, hsts_missing, security_headers, mixed_content, favicon_missing, generic_anchors, broken_external_links
- PSI mobile https://www.clustox.com/: HTTP 429
- PSI desktop https://www.clustox.com/: HTTP 429
- PSI mobile https://www.clustox.com/blog: HTTP 429
- PSI desktop https://www.clustox.com/blog: HTTP 429
- PSI mobile https://www.clustox.com/contact-us: HTTP 429
- PSI desktop https://www.clustox.com/contact-us: HTTP 429

Jev ledger: {'model_requested': 'jev-latest', 'model_returned': None, 'requests': 0, 'failed': 0, 'input_tokens': 0, 'output_tokens': 0, 'est_reserved_tokens': 0, 'skipped_budget': 0, 'errors': []}
