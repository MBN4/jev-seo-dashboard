# Jev SEO audit: mycoldinbox.com

Audited 2026-11-25T13:21:34+00:00 · 49 URLs crawled · 49 HTML pages · 0 Jev judgments · Jev cost $0.0000

**Overall score: 97/100 (grade A)**

> **Partial audit:** Jev judgments unavailable, so content quality was not assessed; PageSpeed Insights unavailable, so performance used crawl timings only. The overall score covers only the areas that were assessed.

<img src="charts/gauge.png" alt="Overall score" width="220">

| Area | Score | Weight | How it is scored |
|---|---:|---:|---|
| Crawl and indexing | 88 | 20 | Rules only |
| On-page | 99 | 15 | Rules only |
| Content quality | n/a | 20 | Not assessed: Jev judgments unavailable |
| Links and architecture | 100 | 10 | Rules only |
| Structured data and sharing | 98 | 8 | Rules only |
| AI search readiness | 100 | 12 | Rules only: Jev judgments unavailable; editorial heuristics, since Google states no special optimization is required for AI features |
| Performance | 100 | 10 | Crawl observations only: PageSpeed Insights unavailable |
| Security and trust | 100 | 5 | Rules only |
| Search visibility and authority | n/a | 15 | Not assessed: run with --full (DataForSEO) |

<img src="charts/categories.png" alt="Score by area" width="640">

**Contents:** [Executive summary](#executive-summary) · [How this audit was made](#how-this-audit-was-made) · [Priority actions](#priority-actions) · [What the crawl found](#what-the-crawl-found) · [Findings by area](#findings-by-area) · [Robots access](#robots-access) · [Page inventory](#page-inventory) · [Method and limits](#method-and-limits)

## Executive summary

mycoldinbox.com scores 97 out of 100 (grade A) across 7 scored areas. The strongest areas are links and architecture, AI search readiness, performance; the weakest are crawl and indexing, structured data and sharing, on-page. The audit produced 4 actions, 1 of them marked fix first and 1 quick wins.

**What is working**

- Links and architecture scores 100.
- AI search readiness scores 100.
- Performance scores 100.

**What is holding the site back**

- JEV-001: Pages excluded from search with noindex (2 pages carry noindex)

### Plan

**This week**

- JEV-001 Pages excluded from search with noindex

**This month**

- JEV-002 Missing pages return HTTP 200 (soft 404)

**This quarter**

- JEV-003 Structured data missing properties Google requires for rich results
- JEV-004 Very short or very long titles

_Written by: Automatic summary (no lead-agent narrative was written)._

## How this audit was made

A source finds, code decides, Jev judges, Claude writes. Code crawls, counts and scores. Jev (TypeSafe's System One model) answers narrow typed questions about meaning, with probabilities. Missing data is shown as missing.

```mermaid
flowchart LR
  A[Crawl<br/>49 URLs] --> B[Rules<br/>5 findings] --> C[Jev judges<br/>0 judgments] --> D[PageSpeed<br/>0 runs] --> E[Score and write<br/>4 actions]
  style C fill:#d45bb6,color:#fff
```

## Priority actions

<img src="charts/impact_effort.png" alt="Impact versus effort" width="640">

| ID | Action | Priority | Impact | Effort | Pages | By | Verify |
|---|---|---|---:|---|---:|---|---:|
| JEV-001 | Pages excluded from search with noindex (quick win) | P1 Fix first | 100 | Hours | 2 | rule |  |
| JEV-002 | Missing pages return HTTP 200 (soft 404) | P2 Plan next | 81 | About a day | 1 | rule |  |
| JEV-003 | Structured data missing properties Google requires for rich results | P3 When convenient | 27 | Hours | 49 | rule |  |
| JEV-004 | Very short or very long titles | P3 When convenient | 17 | Hours | 3 | rule |  |

```mermaid
pie showData title Actions by severity
    "high" : 1
    "medium" : 1
    "low" : 2
```

<img src="charts/severity_by_category.png" alt="Actions by area and severity" width="640">

## What the crawl found

<img src="charts/funnel.png" alt="From discovered URLs to Jev judgments" width="640">

<img src="charts/site_map.png" alt="Site structure by click depth" width="640">

## Findings by area

### Crawl and indexing (88)

**JEV-001 · Pages excluded from search with noindex** `P1` `high` `rule`

- Evidence: 2 affected · 2 pages carry noindex
- Fix: Confirm each noindex is intended; remove it from pages that should rank. ([source](https://developers.google.com/search/docs/crawling-indexing/block-indexing))
- URLs: https://mycoldinbox.com/privacy-policy, https://mycoldinbox.com/terms-of-use

**JEV-002 · Missing pages return HTTP 200 (soft 404)** `P2` `medium` `rule`

- Evidence: 1 affected · A random nonexistent URL returned HTTP 200
- Fix: Return a real 404 or 410 status for URLs that do not exist. ([source](https://developers.google.com/crawling/docs/troubleshooting/http-status-codes))
- URLs: https://mycoldinbox.com/jevseo-…-not-found

### On-page (99)

**JEV-004 · Very short or very long titles** `P3` `low` `rule` `heuristic`

- Evidence: 3 affected · 67 chars; 68 chars; 67 chars
- Fix: Aim for a concise, descriptive title. Google truncates by pixel width, so there is no fixed limit; 15 to 65 characters is a display convention. ([source](https://developers.google.com/search/docs/appearance/title-link))
- URLs: https://mycoldinbox.com/features/unified-inbox, https://mycoldinbox.com/features/status-tracking, https://mycoldinbox.com/for-lead-gen-businesses

### Structured data and sharing (98)

**JEV-003 · Structured data missing properties Google requires for rich results** `P3` `low` `rule`

- Evidence: 49 affected · SoftwareApplication on / lacks aggregateRating or review; SoftwareApplication on /features lacks aggregateRating or review; SoftwareApplication on /features/unified-inbox lacks aggregateRating or review; SoftwareApplication on /features/reply-management lacks aggregateRating or review; SoftwareApplication on /features/thread-assignment lacks aggregateRating or review; SoftwareApplication on /features/team-workspace lacks aggregateRating or review; and 43 more
- Fix: Add the missing required properties listed in the evidence, or remove markup that cannot be completed truthfully. ([source](https://developers.google.com/search/docs/appearance/structured-data/intro-structured-data))
- URLs: https://mycoldinbox.com/, https://mycoldinbox.com/about, https://mycoldinbox.com/alternatives, https://mycoldinbox.com/contact, https://mycoldinbox.com/es, https://mycoldinbox.com/es/alternatives, https://mycoldinbox.com/es/features, https://mycoldinbox.com/es/features/inbox-search and 41 more

## Robots access

| User agent | Access |
|---|---|
| Googlebot | allowed |
| Bingbot | allowed |
| GPTBot | allowed |
| OAI-SearchBot | allowed |
| ChatGPT-User | allowed |
| ClaudeBot | allowed |
| Claude-SearchBot | allowed |
| PerplexityBot | allowed |
| Google-Extended | allowed |
| Applebot-Extended | allowed |
| CCBot | allowed |
| Bytespider | allowed |

## Page inventory

| Page | Depth | Words | Inlinks | Type (Jev) | Intent (Jev) | Importance | Action (Jev) |
|---|---:|---:|---:|---|---|---:|---|
| https://mycoldinbox.com/ | 0 | 1821 | 27 |  |  |  |  |
| https://mycoldinbox.com/about | 1 | 432 | 26 |  |  |  |  |
| https://mycoldinbox.com/alternatives | 1 | 752 | 27 |  |  |  |  |
| https://mycoldinbox.com/contact | 1 | 1612 | 26 |  |  |  |  |
| https://mycoldinbox.com/es | 1 | 2121 | 22 |  |  |  |  |
| https://mycoldinbox.com/features | 1 | 526 | 27 |  |  |  |  |
| https://mycoldinbox.com/features/inbox-search | 1 | 2780 | 27 |  |  |  |  |
| https://mycoldinbox.com/features/internal-notes | 1 | 2560 | 27 |  |  |  |  |
| https://mycoldinbox.com/features/multi-account-view | 1 | 2918 | 27 |  |  |  |  |
| https://mycoldinbox.com/features/reply-management | 1 | 2523 | 27 |  |  |  |  |
| https://mycoldinbox.com/features/status-tracking | 1 | 1412 | 27 |  |  |  |  |
| https://mycoldinbox.com/features/team-workspace | 1 | 2935 | 27 |  |  |  |  |
| https://mycoldinbox.com/features/thread-assignment | 1 | 2365 | 27 |  |  |  |  |
| https://mycoldinbox.com/features/unified-inbox | 1 | 2615 | 27 |  |  |  |  |
| https://mycoldinbox.com/for-cold-email-agencies | 1 | 1320 | 27 |  |  |  |  |
| https://mycoldinbox.com/for-lead-gen-businesses | 1 | 1350 | 27 |  |  |  |  |
| https://mycoldinbox.com/for-recruiters | 1 | 1235 | 27 |  |  |  |  |
| https://mycoldinbox.com/for-saas-founders | 1 | 1218 | 27 |  |  |  |  |
| https://mycoldinbox.com/for-sdr-teams | 1 | 1311 | 27 |  |  |  |  |
| https://mycoldinbox.com/glossary | 1 | 617 | 48 |  |  |  |  |
| https://mycoldinbox.com/pricing | 1 | 945 | 27 |  |  |  |  |
| https://mycoldinbox.com/privacy-policy | 1 | 4638 | 48 |  |  |  |  |
| https://mycoldinbox.com/terms-of-use | 1 | 4726 | 48 |  |  |  |  |
| https://mycoldinbox.com/vs-front | 1 | 1294 | 27 |  |  |  |  |
| https://mycoldinbox.com/vs-gmelius | 1 | 1287 | 27 |  |  |  |  |
| https://mycoldinbox.com/vs-help-scout | 1 | 1307 | 27 |  |  |  |  |
| https://mycoldinbox.com/vs-hiver | 1 | 1286 | 27 |  |  |  |  |
| https://mycoldinbox.com/vs-missive | 1 | 1291 | 27 |  |  |  |  |
| https://mycoldinbox.com/es/alternatives | 2 | 886 | 22 |  |  |  |  |
| https://mycoldinbox.com/es/features | 2 | 619 | 22 |  |  |  |  |
| https://mycoldinbox.com/es/features/inbox-search | 2 | 3269 | 22 |  |  |  |  |
| https://mycoldinbox.com/es/features/internal-notes | 2 | 3017 | 22 |  |  |  |  |
| https://mycoldinbox.com/es/features/multi-account-view | 2 | 3493 | 22 |  |  |  |  |
| https://mycoldinbox.com/es/features/reply-management | 2 | 2969 | 22 |  |  |  |  |
| https://mycoldinbox.com/es/features/status-tracking | 2 | 1701 | 22 |  |  |  |  |
| https://mycoldinbox.com/es/features/team-workspace | 2 | 3679 | 22 |  |  |  |  |
| https://mycoldinbox.com/es/features/thread-assignment | 2 | 2854 | 22 |  |  |  |  |
| https://mycoldinbox.com/es/features/unified-inbox | 2 | 3127 | 22 |  |  |  |  |
| https://mycoldinbox.com/es/for-cold-email-agencies | 2 | 1610 | 22 |  |  |  |  |
| https://mycoldinbox.com/es/for-lead-gen-businesses | 2 | 1600 | 22 |  |  |  |  |
| https://mycoldinbox.com/es/for-recruiters | 2 | 1460 | 22 |  |  |  |  |
| https://mycoldinbox.com/es/for-saas-founders | 2 | 1407 | 22 |  |  |  |  |
| https://mycoldinbox.com/es/for-sdr-teams | 2 | 1563 | 22 |  |  |  |  |
| https://mycoldinbox.com/es/pricing | 2 | 1026 | 22 |  |  |  |  |
| https://mycoldinbox.com/es/vs-front | 2 | 1569 | 22 |  |  |  |  |
| https://mycoldinbox.com/es/vs-gmelius | 2 | 1556 | 22 |  |  |  |  |
| https://mycoldinbox.com/es/vs-help-scout | 2 | 1594 | 22 |  |  |  |  |
| https://mycoldinbox.com/es/vs-hiver | 2 | 1566 | 22 |  |  |  |  |
| https://mycoldinbox.com/es/vs-missive | 2 | 1571 | 22 |  |  |  |  |

## Method and limits

- Area score: 100 minus, per finding, severity amount (critical 25, high 12, medium 6, low 2) × (0.5 + 0.5 × share of pages affected). Content and AI readiness blend 70% Jev judgment with 30% rules. Performance blends 50% Lighthouse mobile with 50% crawl observations.
- Overall: weighted mean of scored areas; unscored areas are excluded, never zero.
- Impact: severity weight × (0.6 + 0.4 × reach) × (0.6 + 0.8 × highest Jev importance of affected pages), scaled to 100.
- Jev answers are decisive at confidence 0.80 (Choice, Score) or P(yes) at least 0.80 or at most 0.20 (Noul). Others are flagged to verify.
- Jev: model n/a, 0 requests, 0 input tokens, 0 failed, cost $0.0000.
- No Search Console, analytics, backlink or keyword data was used (run with --full for DataForSEO).
- Scores rank work; they do not predict rankings or traffic.

_Generated by jev-seo 0.1.1._
