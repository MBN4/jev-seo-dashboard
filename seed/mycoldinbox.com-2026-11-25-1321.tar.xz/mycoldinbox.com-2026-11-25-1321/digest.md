# Digest: mycoldinbox.com
Audited 2026-11-25T13:21:34+00:00. Pages fetched: 49; HTML pages: 49.
Overall 97 (A). Crawl and indexing 88, On-page 99, Content quality n/a, Links and architecture 100, Structured data and sharing 98, AI search readiness 100, Performance 100, Security and trust 100, Search visibility and authority n/a
Caps: none. Completeness: {'categories_scored': 7, 'categories_total': 9, 'jev': False, 'jev_pages_not_judged': 0, 'pagespeed': False, 'dataforseo': False}
PARTIAL AUDIT: Jev judgments unavailable, so content quality was not assessed; PageSpeed Insights unavailable, so performance used crawl timings only. Say so in the narrative.
Homepage: title='Email Management Software for Multi-Inbox Teams - MyColdInbox'; h1=['Turn Cold Email Replies Into Sales Opportunities']; meta='Team email management software for outreach. Connect every Gmail, Outlook, and custom SMTP/IMAP account in one shared inbox, assign threads, never miss a reply.'

## Actions (id, priority, impact, effort, count, title, evidence, review flags)
- JEV-001 P1 impact 100 effort 1 [rule/crawl/high] Pages excluded from search with noindex x2: 2 pages carry noindex
  URLs: /privacy-policy, /terms-of-use
- JEV-002 P2 impact 81 effort 2 [rule/crawl/medium] Missing pages return HTTP 200 (soft 404) x1: A random nonexistent URL returned HTTP 200
  URLs: /jevseo-…-not-found
- JEV-003 P3 impact 27 effort 1 [rule/structured/low] Structured data missing properties Google requires for rich results x49: SoftwareApplication on / lacks aggregateRating or review; SoftwareApplication on /features lacks aggregateRating or review; SoftwareApplication on /features/unified-inbox lacks aggregateRating or review; SoftwareApplication on /features/reply-management lacks aggregateRating or review; SoftwareApplication on /features/thread-assignment lacks aggregateRating or review; SoftwareApplication on /features/team-workspace lacks aggregateRating or review; and 43 more
  URLs: /, /about, /alternatives, /contact, /es, /es/alternatives, /es/features, /es/features/inbox-search +41 more
- JEV-004 P3 impact 17 effort 1 [rule/onpage/low] Very short or very long titles x3: 67 chars; 68 chars; 67 chars
  URLs: /features/unified-inbox, /features/status-tracking, /for-lead-gen-businesses

Robots: search bots {'Googlebot': True, 'Bingbot': True}; AI bots checked (10): {'GPTBot': True, 'OAI-SearchBot': True, 'ChatGPT-User': True, 'ClaudeBot': True, 'Claude-SearchBot': True, 'PerplexityBot': True, 'Google-Extended': True, 'Applebot-Extended': True, 'CCBot': True, 'Bytespider': True}

## No issue detected by rule
robots_missing, robots_blocks_site, sitemap_missing, sitemap_errors, sitemap_bad_urls, not_in_sitemap, http_errors, broken_internal_links, redirect_chains, links_to_redirects, canonical_missing, canonical_elsewhere, canonical_broken, host_temporary_redirect, host_variant, no_https, deep_pages, orphan_pages, js_dependent, title_missing, title_duplicate, multiple_titles, meta_missing, meta_duplicate, h1_missing, h1_multiple, heading_skips, lang_missing, viewport_missing, thin_content, duplicate_content, images_alt, images_dimensions, no_structured_data, jsonld_errors, og_missing, hreflang_issues, ai_bots_blocked, llms_txt_missing, hsts_missing, security_headers, mixed_content, favicon_missing, slow_ttfb, heavy_html, generic_anchors, broken_external_links
- PSI mobile https://mycoldinbox.com/: HTTP 429
- PSI desktop https://mycoldinbox.com/: HTTP 429
- PSI mobile https://mycoldinbox.com/glossary: HTTP 429
- PSI desktop https://mycoldinbox.com/glossary: HTTP 429
- PSI mobile https://mycoldinbox.com/features: HTTP 429
- PSI desktop https://mycoldinbox.com/features: HTTP 429

Jev ledger: {'model_requested': 'jev-latest', 'model_returned': None, 'requests': 0, 'failed': 0, 'input_tokens': 0, 'output_tokens': 0, 'est_reserved_tokens': 0, 'skipped_budget': 0, 'errors': []}
