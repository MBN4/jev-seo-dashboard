# Digest: emailverify.io
Audited 2026-11-25T13:38:48+00:00. Pages fetched: 1620; HTML pages: 1580.
Overall 84 (B). Crawl and indexing 71, On-page 74, Content quality n/a, Links and architecture 81, Structured data and sharing 95, AI search readiness 100, Performance 94, Security and trust 98, Search visibility and authority n/a
Caps: none. Completeness: {'categories_scored': 7, 'categories_total': 9, 'jev': False, 'jev_pages_not_judged': 0, 'pagespeed': False, 'dataforseo': False}
PARTIAL AUDIT: Jev judgments unavailable, so content quality was not assessed; PageSpeed Insights unavailable, so performance used crawl timings only. Say so in the narrative.
Homepage: title='Email Verification Service & Email Verifier | EmailVerify.io'; h1=['Free Email Verifier & Validator — Verify Email Addresses Before You Send']; meta='Verify email addresses free with our email checker & validator. Clean bulk email lists in real time, cut bounces and catch spam traps. 100 free credits, no card.'

## Actions (id, priority, impact, effort, count, title, evidence, review flags)
- JEV-001 P1 impact 100 effort 2 [rule/links/high] Internal links pointing to broken URLs x1463: 4 broken targets: 404 https://www.emailverify.io/cdn-cgi/l/email-protection (linked from /, /api); unreachable https://www.emailverify.io/id/integrations/[https:/app.emailverify.io?locale=id](https://app.emailverify.io?locale=id) (linked from /id/integrations/monday); unreachable https://www.emailverify.io/nl/integrations/[https:/app.emailverify.io?locale=nl](https://app.emailverify.io?locale=nl) (linked from /nl/integrations/monday); unreachable https://www.emailverify.io/tr/integrations/[https:/app.emailverify.io?locale=tr](https://app.emailverify.io?locale=tr) (linked from /tr/integrations/monday)
  URLs: /, /api, /api/bulk-email-verification, /api/docs, /api/email-finder, /api/email-verification, /ar, /ar/api +1455 more
- JEV-002 P1 impact 63 effort 1 [rule/onpage/high] No mobile viewport meta tag x54: 54 pages
  URLs: /docs/getting-started-with-emailverify-io, /docs/security-and-privacy, /docs/understanding-results, /docs/instant-verification, /docs/bulk-email-verification, /docs/email-finder, /docs/bulk-email-finder, /docs/api-documentation +46 more
- JEV-003 P1 impact 62 effort 1 [rule/crawl/high] Pages excluded from search with noindex x7: 7 pages carry noindex
  URLs: /blog/category/email-verification/page/2, /blog/category/email-verification/page/3, /blog/author/maryam/page/2, /blog/author/fiza-shahid/page/2, /blog/author/fiza-shahid/page/3, /blog/category/email-deliverability/page/2, /blog/category/email-deliverability/page/3
- JEV-004 P1 impact 62 effort 2 [rule/crawl/high] Pages returning HTTP errors x1: 404
  URLs: /cdn-cgi/l/email-protection
- JEV-005 P2 impact 52 effort 2 [rule/crawl/medium] Missing pages return HTTP 200 (soft 404) x1: A random nonexistent URL returned HTTP 200
  URLs: /jevseo-…-not-found
- JEV-006 P2 impact 50 effort 2 [rule/onpage/medium] Images without alt attributes x1448: 1801 images without alt across 1448 pages
  URLs: /, /pricing, /pricing, /services/email-verify, /services/bulk-email-verification, /services/email-finder, /services/bulk-email-finder, /buying-radar +1440 more
- JEV-007 P2 impact 32 effort 3 [rule/performance/medium] Slow server response (TTFB above 0.8 s) x101: /blog/why-emails-go-to-spam: 993 ms; /blog/b2b-email-validation-to-stop-bad-leads: 1048 ms; /blog/verify-email-address-without-sending: 878 ms; /blog/disposable-emails: 1380 ms; /blog/ways-to-verify-email-address-before-sending: 1160 ms; /blog/real-time-vs-bulk-email-verification: 868 ms
  URLs: /blog/why-emails-go-to-spam, /blog/b2b-email-validation-to-stop-bad-leads, /blog/verify-email-address-without-sending, /blog/disposable-emails, /blog/ways-to-verify-email-address-before-sending, /blog/real-time-vs-bulk-email-verification, /docs/instant-verification, /docs/bulk-email-verification +93 more
- JEV-008 P2 impact 31 effort 1 [rule/crawl/medium] Redirect chains (more than one hop) x38: https://www.emailverify.io/services/bulk-email-verify (2 hops); https://www.emailverify.io/docs (3 hops); https://www.emailverify.io/blog/verify-emails-before-sending (2 hops); https://www.emailverify.io/blog/verify-email-address-without-sending (2 hops); https://emailverify.io/pricing (2 hops)
  URLs: /services/bulk-email-verify, /docs, /blog/verify-emails-before-sending, /blog/verify-email-address-without-sending, emailverify.io/pricing, /integrations, /users/sign_up, /docs/emailverify.io +30 more
- JEV-009 P2 impact 31 effort 1 [rule/crawl/medium] Canonical points to a different URL x2: https://www.emailverify.io/pricing?billing=annual -> https://www.emailverify.io/pricing; https://www.emailverify.io/services/email-verify?utm_source=chatgpt.com -> https://www.emailverify.io/services/email-verify
  URLs: /pricing, /services/email-verify
- JEV-010 P2 impact 31 effort 1 [rule/onpage/medium] Duplicate titles across pages x23: 10 titles shared by several pages
  URLs: /blog/author/fiza-shahid, /blog/author/fiza-shahid/page/2, /blog/author/fiza-shahid/page/3, /blog/author/maryam, /blog/author/maryam/page/2, /blog/category/email-deliverability, /blog/category/email-deliverability/page/2, /blog/category/email-deliverability/page/3 +15 more
- JEV-011 P2 impact 31 effort 1 [rule/onpage/medium] Pages without a meta description x2: 2 indexable pages
  URLs: /docs/integrations/integration-with-gohighlevel, /blog/author/ayesha
- JEV-012 P2 impact 31 effort 1 [rule/onpage/medium] Pages without an H1 heading x5: 5 indexable pages
  URLs: /blog/author/maryam, /blog/author/fiza-shahid, /blog/author/anusha, /blog/author/editorialteam, /blog/author/ayesha
- JEV-013 P2 impact 31 effort 2 [rule/crawl/medium] Sitemap lists URLs that redirect, fail or are noindex x4: 4 of the crawled sitemap URLs are not final indexable pages
  URLs: /blog/b2b-email-validation, /blog/email-throttling, /blog/smtp-check, /blog/verify-emails-before-sending
- JEV-014 P2 impact 31 effort 2 [rule/links/medium] Sitemap pages with no internal links (orphans) x27: 27 sitemap pages received no internal links from the crawled pages: /it/benefits, /tr/benefits, /de/benefits, /nl/benefits, /ar/benefits, /zh/benefits
  URLs: /it/benefits, /tr/benefits, /de/benefits, /nl/benefits, /ar/benefits, /zh/benefits, /id/benefits, /ru/benefits +19 more
- JEV-015 P2 impact 31 effort 2 [rule/content/medium] Pages with identical main text x4: 2 groups of pages with identical main text
  URLs: /pricing, /pricing, /services/email-verify, /services/email-verify
- JEV-016 P2 impact 31 effort 2 [rule/structured/medium] hreflang annotations incomplete x2: 2 pages with hreflang but no self-reference
  URLs: /pricing, /services/email-verify
- JEV-017 P2 impact 31 effort 3 [rule/content/medium] Pages with very little main content x42: /jp/support: 73 words; /jp/compare: 52 words; /zh/compare: 104 words; /zh/support: 89 words; /zh/benefits: 81 words; /jp/benefits: 65 words; /jp/libraries: 59 words; /zh/libraries: 119 words
  URLs: /jp/support, /jp/compare, /zh/compare, /zh/support, /zh/benefits, /jp/benefits, /jp/libraries, /zh/libraries +34 more
- JEV-018 P3 impact 17 effort 1 [rule/links/low] Internal links that go through a redirect x1532: / links to emailverify.io/ (redirects to /); / links to /blog/verify-emails-before-sending (redirects to /blog/verify-email-address-without-sending); / links to /docs (redirects to /docs/getting-started-with-emailverify-io); / links to /services/bulk-email-verify (redirects to /); /pricing links to /blog/verify-emails-before-sending (redirects to /blog/verify-email-address-without-sending); and 3634 more
  URLs: /, /api, /api/bulk-email-verification, /api/docs, /api/email-finder, /api/email-verification, /ar, /ar/api +1524 more
- JEV-019 P3 impact 17 effort 1 [rule/security/low] Common security headers missing x1: Missing on the homepage response: referrer-policy
  URLs: /
- JEV-020 P3 impact 16 effort 1 [rule/performance/low] Images without width and height x1345: 8987 images without explicit size
  URLs: /, /pricing, /pricing, /services/email-verify, /services/bulk-email-verification, /services/email-finder, /services/bulk-email-finder, /buying-radar +1337 more
- JEV-021 P3 impact 14 effort 1 [rule/onpage/low] Very short or very long titles x809: 71 chars; 67 chars; 69 chars; 70 chars; 133 chars; 91 chars; 84 chars; 80 chars
  URLs: /services/bulk-email-verification, /services/email-finder, /services/bulk-email-finder, /buying-radar, /integrations/klaviyo, /integrations/zapier, /integrations/n8n, /integrations/docs +801 more
- JEV-022 P3 impact 11 effort 1 [rule/onpage/low] Heading levels skipped x83: 83 pages skip a heading level
  URLs: /integrations/docs, /tools/dmarc-checker, /tools/dmarc-generator, /blog/how-to-verify-an-email-address, /blog/why-emails-go-to-spam, /blog/b2b-email-validation-to-stop-bad-leads, /blog/verify-email-address-without-sending, /blog/smtp-verification +75 more
- JEV-023 P3 impact 11 effort 1 [rule/structured/low] Structured data missing properties Google requires for rich results x107: SoftwareApplication on /solutions/smbs lacks offers.price, aggregateRating or review; SoftwareApplication on /solutions/agencies lacks offers.price, aggregateRating or review; SoftwareApplication on /solutions/enterprise lacks offers.price, aggregateRating or review; SoftwareApplication on /solutions/email-marketing lacks offers.price, aggregateRating or review; SoftwareApplication on /solutions/business-development lacks offers.price, aggregateRating or review; SoftwareApplication on /solutions/developers lacks offers.price, aggregateRating or review; and 101 more
  URLs: /ar/solutions/agencies, /ar/solutions/business-development, /ar/solutions/class-action-settlements, /ar/solutions/developers, /ar/solutions/email-marketing, /ar/solutions/enterprise, /ar/solutions/smbs, /ar/support +99 more
- JEV-024 P3 impact 11 effort 1 [rule/structured/low] Open Graph title or image missing x60: 60 pages lack og:title or og:image
  URLs: /docs/getting-started-with-emailverify-io, /docs/security-and-privacy, /docs/understanding-results, /docs/instant-verification, /docs/bulk-email-verification, /docs/email-finder, /docs/bulk-email-finder, /docs/api-documentation +52 more
- JEV-025 P3 impact 10 effort 1 [rule/crawl/low] Indexable pages missing from the sitemap x1: 1 crawled indexable pages are not listed
  URLs: /buying-radar
- JEV-026 P3 impact 10 effort 1 [rule/links/low] Internal links with generic anchor text x15: Anchors such as: Go, Learn more
  URLs: /, /api, /ar/api, /de/api, /es/api, /fr/api, /id/api, /it/api +7 more
- JEV-027 P3 impact 10 effort 1 [rule/crawl/low] Pages without a canonical link x7: 7 of 1580 pages
  URLs: /blog/category/email-verification/page/2, /blog/category/email-verification/page/3, /blog/author/maryam/page/2, /blog/author/fiza-shahid/page/2, /blog/author/fiza-shahid/page/3, /blog/category/email-deliverability/page/2, /blog/category/email-deliverability/page/3
- JEV-028 P3 impact 10 effort 1 [rule/onpage/low] Duplicate meta descriptions x19: 8 descriptions shared by several pages
  URLs: /blog/author/fiza-shahid, /blog/author/fiza-shahid/page/2, /blog/author/fiza-shahid/page/3, /blog/author/maryam, /blog/author/maryam/page/2, /blog/category/email-deliverability, /blog/category/email-deliverability/page/2, /blog/category/email-deliverability/page/3 +11 more
- JEV-029 P3 impact 10 effort 1 [rule/onpage/low] HTML lang attribute missing x14: 14 pages
  URLs: /integrations/klaviyo, /ru/integrations/klaviyo, /jp/integrations/klaviyo, /de/integrations/klaviyo, /id/integrations/klaviyo, /pt/integrations/klaviyo, /nl/integrations/klaviyo, /ar/integrations/klaviyo +6 more
- JEV-030 P3 impact 10 effort 2 [rule/links/low] Pages more than three clicks from the homepage x1: 1 page deeper than three clicks
  URLs: /services/email-verify
- JEV-031 P3 impact 10 effort 2 [rule/performance/low] Very large HTML documents (over 500 KB) x21: /: 581 KB; /docs/getting-started-with-emailverify-io: 840 KB; /docs/bulk-email-verification: 575 KB; /docs/integrations: 584 KB; /docs/integrations/integration-with-zapier: 2134 KB; /docs/integrations/emailverify-io-with-pipedrive-via-integrately: 519 KB
  URLs: /, /docs/getting-started-with-emailverify-io, /docs/bulk-email-verification, /docs/integrations, /docs/integrations/integration-with-zapier, /docs/integrations/emailverify-io-with-pipedrive-via-integrately, /docs/integrations/emailverify-io-with-123-form-builder-via-pabbly, /docs/integrations/emailverify-io-with-8x8-via-pabbly +13 more

Robots: search bots {'Googlebot': True, 'Bingbot': True}; AI bots checked (10): {'GPTBot': True, 'OAI-SearchBot': True, 'ChatGPT-User': True, 'ClaudeBot': True, 'Claude-SearchBot': True, 'PerplexityBot': True, 'Google-Extended': True, 'Applebot-Extended': True, 'CCBot': True, 'Bytespider': True}

## No issue detected by rule
robots_missing, robots_blocks_site, sitemap_missing, sitemap_errors, canonical_broken, host_temporary_redirect, host_variant, no_https, js_dependent, title_missing, multiple_titles, h1_multiple, no_structured_data, jsonld_errors, ai_bots_blocked, llms_txt_missing, hsts_missing, mixed_content, favicon_missing, broken_external_links
- PSI mobile https://www.emailverify.io/: HTTP 429
- PSI desktop https://www.emailverify.io/: HTTP 429
- PSI mobile https://www.emailverify.io/docs/getting-started-with-emailverify-io: HTTP 429
- PSI desktop https://www.emailverify.io/docs/getting-started-with-emailverify-io: HTTP 429
- PSI mobile https://www.emailverify.io/blog/smtp-verification: HTTP 429
- PSI desktop https://www.emailverify.io/blog/smtp-verification: HTTP 429

Jev ledger: {'model_requested': 'jev-latest', 'model_returned': None, 'requests': 0, 'failed': 0, 'input_tokens': 0, 'output_tokens': 0, 'est_reserved_tokens': 0, 'skipped_budget': 0, 'errors': []}
