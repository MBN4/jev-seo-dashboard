# Jev SEO audit: tellbear.com

Audited 2026-11-26T10:43:06+00:00 · 72 URLs crawled · 72 HTML pages · 0 Jev judgments · Jev cost $0.0000

**Overall score: 98/100 (grade A)**

> **Partial audit:** Jev judgments unavailable, so content quality was not assessed; PageSpeed Insights unavailable, so performance used crawl timings only. The overall score covers only the areas that were assessed.

<img src="charts/gauge.png" alt="Overall score" width="220">

| Area | Score | Weight | How it is scored |
|---|---:|---:|---|
| Crawl and indexing | 94 | 20 | Rules only |
| On-page | 99 | 15 | Rules only |
| Content quality | n/a | 20 | Not assessed: Jev judgments unavailable |
| Links and architecture | 100 | 10 | Rules only |
| Structured data and sharing | 99 | 8 | Rules only |
| AI search readiness | 100 | 12 | Rules only: Jev judgments unavailable; editorial heuristics, since Google states no special optimization is required for AI features |
| Performance | 100 | 10 | Crawl observations only: PageSpeed Insights unavailable |
| Security and trust | 100 | 5 | Rules only |
| Search visibility and authority | n/a | 15 | Not assessed: run with --full (DataForSEO) |

<img src="charts/categories.png" alt="Score by area" width="640">

**Contents:** [Executive summary](#executive-summary) · [How this audit was made](#how-this-audit-was-made) · [Priority actions](#priority-actions) · [What the crawl found](#what-the-crawl-found) · [Findings by area](#findings-by-area) · [Robots access](#robots-access) · [Page inventory](#page-inventory) · [Method and limits](#method-and-limits)

## Executive summary

tellbear.com scores 98 out of 100 (grade A) across 7 scored areas. The strongest areas are links and architecture, AI search readiness, performance; the weakest are crawl and indexing, on-page, structured data and sharing. The audit produced 4 actions, 0 of them marked fix first and 1 quick wins.

**What is working**

- Links and architecture scores 100.
- AI search readiness scores 100.
- Performance scores 100.

**What is holding the site back**

- JEV-001: www and non-www both serve the site (www.tellbear.com answers without redirecting to the preferred host)
- JEV-002: Pages with very little main content (/contact: 81 words; /opt-out: 73 words)
- JEV-003: Very short or very long titles (70 chars; 68 chars)
- JEV-004: Structured data missing properties Google requires for rich results (SoftwareApplication on / lacks aggregateRating or review)

### Plan

**This week**

- JEV-001 www and non-www both serve the site

**This month**

- JEV-002 Pages with very little main content

**This quarter**

- JEV-003 Very short or very long titles
- JEV-004 Structured data missing properties Google requires for rich results

_Written by: Automatic summary (no lead-agent narrative was written)._

## How this audit was made

A source finds, code decides, Jev judges, Claude writes. Code crawls, counts and scores. Jev (TypeSafe's System One model) answers narrow typed questions about meaning, with probabilities. Missing data is shown as missing.

```mermaid
flowchart LR
  A[Crawl<br/>72 URLs] --> B[Rules<br/>5 findings] --> C[Jev judges<br/>0 judgments] --> D[PageSpeed<br/>0 runs] --> E[Score and write<br/>4 actions]
  style C fill:#d45bb6,color:#fff
```

## Priority actions

<img src="charts/impact_effort.png" alt="Impact versus effort" width="640">

| ID | Action | Priority | Impact | Effort | Pages | By | Verify |
|---|---|---|---:|---|---:|---|---:|
| JEV-001 | www and non-www both serve the site (quick win) | P2 Plan next | 100 | Hours | 1 | rule |  |
| JEV-002 | Pages with very little main content | P2 Plan next | 61 | Several days | 2 | rule |  |
| JEV-003 | Very short or very long titles | P3 When convenient | 20 | Hours | 2 | rule |  |
| JEV-004 | Structured data missing properties Google requires for rich results | P3 When convenient | 20 | Hours | 1 | rule |  |

```mermaid
pie showData title Actions by severity
    "medium" : 2
    "low" : 2
```

<img src="charts/severity_by_category.png" alt="Actions by area and severity" width="640">

## What the crawl found

<img src="charts/funnel.png" alt="From discovered URLs to Jev judgments" width="640">

<img src="charts/site_map.png" alt="Site structure by click depth" width="640">

## Findings by area

### Crawl and indexing (94)

**JEV-001 · www and non-www both serve the site** `P2` `medium` `rule`

- Evidence: 1 affected · www.tellbear.com answers without redirecting to the preferred host
- Fix: Redirect the alternate host to the preferred host with a permanent redirect. ([source](https://developers.google.com/search/docs/crawling-indexing/consolidate-duplicate-urls))
- URLs: https://www.tellbear.com/

### On-page (99)

**JEV-003 · Very short or very long titles** `P3` `low` `rule` `heuristic`

- Evidence: 2 affected · 70 chars; 68 chars
- Fix: Aim for a concise, descriptive title. Google truncates by pixel width, so there is no fixed limit; 15 to 65 characters is a display convention. ([source](https://developers.google.com/search/docs/appearance/title-link))
- URLs: https://tellbear.com/api, https://tellbear.com/mcp

### Content quality (n/a)

**JEV-002 · Pages with very little main content** `P2` `medium` `rule` `heuristic`

- Evidence: 2 affected · /contact: 81 words; /opt-out: 73 words
- Fix: Expand pages that should rank with substance a visitor needs, or consolidate them. Word count is a warning sign, not a ranking factor. ([source](https://developers.google.com/search/docs/fundamentals/creating-helpful-content))
- URLs: https://tellbear.com/contact, https://tellbear.com/opt-out

### Structured data and sharing (99)

**JEV-004 · Structured data missing properties Google requires for rich results** `P3` `low` `rule`

- Evidence: 1 affected · SoftwareApplication on / lacks aggregateRating or review
- Fix: Add the missing required properties listed in the evidence, or remove markup that cannot be completed truthfully. ([source](https://developers.google.com/search/docs/appearance/structured-data/intro-structured-data))
- URLs: https://tellbear.com/

## Robots access

| User agent | Access |
|---|---|
| Googlebot | allowed |
| Bingbot | allowed |
| GPTBot | allowed |
| OAI-SearchBot | allowed |
| ChatGPT-User | allowed |
| ClaudeBot | allowed |
| Claude-SearchBot | allowed |
| PerplexityBot | allowed |
| Google-Extended | allowed |
| Applebot-Extended | allowed |
| CCBot | allowed |
| Bytespider | allowed |

## Page inventory

| Page | Depth | Words | Inlinks | Type (Jev) | Intent (Jev) | Importance | Action (Jev) |
|---|---:|---:|---:|---|---|---:|---|
| https://tellbear.com/ | 0 | 1483 | 71 |  |  |  |  |
| https://tellbear.com/about | 1 | 595 | 71 |  |  |  |  |
| https://tellbear.com/ad-signals | 1 | 437 | 71 |  |  |  |  |
| https://tellbear.com/api | 1 | 929 | 71 |  |  |  |  |
| https://tellbear.com/api/docs | 1 | 2282 | 71 |  |  |  |  |
| https://tellbear.com/buying-signals | 1 | 1026 | 71 |  |  |  |  |
| https://tellbear.com/changelog | 1 | 457 | 71 |  |  |  |  |
| https://tellbear.com/compare | 1 | 615 | 71 |  |  |  |  |
| https://tellbear.com/contact | 1 | 81 | 71 |  |  |  |  |
| https://tellbear.com/features | 1 | 923 | 71 |  |  |  |  |
| https://tellbear.com/hiring-signals | 1 | 396 | 71 |  |  |  |  |
| https://tellbear.com/how-it-works | 1 | 500 | 71 |  |  |  |  |
| https://tellbear.com/mcp | 1 | 1413 | 71 |  |  |  |  |
| https://tellbear.com/opt-out | 1 | 73 | 71 |  |  |  |  |
| https://tellbear.com/pricing | 1 | 772 | 71 |  |  |  |  |
| https://tellbear.com/privacy-policy | 1 | 4110 | 71 |  |  |  |  |
| https://tellbear.com/security | 1 | 528 | 71 |  |  |  |  |
| https://tellbear.com/solutions | 1 | 213 | 71 |  |  |  |  |
| https://tellbear.com/solutions/agencies | 1 | 546 | 71 |  |  |  |  |
| https://tellbear.com/solutions/developers | 1 | 516 | 22 |  |  |  |  |
| https://tellbear.com/solutions/founders | 1 | 530 | 71 |  |  |  |  |
| https://tellbear.com/solutions/investors | 1 | 510 | 71 |  |  |  |  |
| https://tellbear.com/solutions/marketing | 1 | 535 | 71 |  |  |  |  |
| https://tellbear.com/solutions/recruiters | 1 | 482 | 71 |  |  |  |  |
| https://tellbear.com/solutions/sales | 1 | 569 | 71 |  |  |  |  |
| https://tellbear.com/technologies | 1 | 222 | 71 |  |  |  |  |
| https://tellbear.com/technology/amplitude | 1 | 1236 | 71 |  |  |  |  |
| https://tellbear.com/technology/angular | 1 | 930 | 71 |  |  |  |  |
| https://tellbear.com/technology/cloudflare | 1 | 1166 | 71 |  |  |  |  |
| https://tellbear.com/technology/contentful | 1 | 1436 | 71 |  |  |  |  |
| https://tellbear.com/technology/dns-host | 1 | 1332 | 71 |  |  |  |  |
| https://tellbear.com/technology/gatsby | 1 | 908 | 71 |  |  |  |  |
| https://tellbear.com/technology/google-ads | 1 | 1692 | 71 |  |  |  |  |
| https://tellbear.com/technology/google-analytics | 1 | 1369 | 71 |  |  |  |  |
| https://tellbear.com/technology/google-tag-manager | 1 | 1628 | 71 |  |  |  |  |
| https://tellbear.com/technology/hotjar | 1 | 1277 | 71 |  |  |  |  |
| https://tellbear.com/technology/hubspot | 1 | 958 | 71 |  |  |  |  |
| https://tellbear.com/technology/intercom | 1 | 926 | 71 |  |  |  |  |
| https://tellbear.com/technology/klaviyo | 1 | 868 | 71 |  |  |  |  |
| https://tellbear.com/technology/laravel | 1 | 881 | 71 |  |  |  |  |
| https://tellbear.com/technology/meta-pixel | 1 | 1683 | 71 |  |  |  |  |
| https://tellbear.com/technology/mixpanel | 1 | 1213 | 71 |  |  |  |  |
| https://tellbear.com/technology/netlify | 1 | 1089 | 71 |  |  |  |  |
| https://tellbear.com/technology/nextjs | 1 | 943 | 71 |  |  |  |  |
| https://tellbear.com/technology/nuxtjs | 1 | 908 | 71 |  |  |  |  |
| https://tellbear.com/technology/react | 1 | 821 | 71 |  |  |  |  |
| https://tellbear.com/technology/salesforce | 1 | 887 | 71 |  |  |  |  |
| https://tellbear.com/technology/segment | 1 | 1243 | 71 |  |  |  |  |
| https://tellbear.com/technology/shopify | 1 | 1082 | 71 |  |  |  |  |
| https://tellbear.com/technology/spf-dkim-records | 1 | 1193 | 71 |  |  |  |  |
| https://tellbear.com/technology/squarespace | 1 | 1033 | 71 |  |  |  |  |
| https://tellbear.com/technology/ssl-tls-certificate-provider | 1 | 1326 | 71 |  |  |  |  |
| https://tellbear.com/technology/stripe | 1 | 1030 | 71 |  |  |  |  |
| https://tellbear.com/technology/svelte | 1 | 932 | 71 |  |  |  |  |
| https://tellbear.com/technology/tailwind-css | 1 | 975 | 71 |  |  |  |  |
| https://tellbear.com/technology/tiktok-pixel | 1 | 1694 | 71 |  |  |  |  |
| https://tellbear.com/technology/vercel | 1 | 1094 | 71 |  |  |  |  |
| https://tellbear.com/technology/vuejs | 1 | 949 | 71 |  |  |  |  |
| https://tellbear.com/technology/webflow | 1 | 1060 | 71 |  |  |  |  |
| https://tellbear.com/technology/wix | 1 | 1076 | 71 |  |  |  |  |
| https://tellbear.com/technology/wordpress | 1 | 1120 | 71 |  |  |  |  |
| https://tellbear.com/technology/zendesk | 1 | 891 | 71 |  |  |  |  |
| https://tellbear.com/terms-of-use | 1 | 4074 | 71 |  |  |  |  |
| https://tellbear.com/compare/autobound-alternative | 2 | 1067 | 1 |  |  |  |  |
| https://tellbear.com/compare/common-room-alternative | 2 | 1064 | 1 |  |  |  |  |
| https://tellbear.com/compare/ocean-io-alternative | 2 | 1062 | 1 |  |  |  |  |
| https://tellbear.com/compare/predictleads-alternative | 2 | 1053 | 1 |  |  |  |  |
| https://tellbear.com/compare/theirstack-alternative | 2 | 1061 | 1 |  |  |  |  |
| https://tellbear.com/compare/unify-alternative | 2 | 1059 | 1 |  |  |  |  |
| https://tellbear.com/solutions/ecommerce | 2 | 514 | 13 |  |  |  |  |
| https://tellbear.com/solutions/enterprise | 2 | 498 | 11 |  |  |  |  |
| https://tellbear.com/solutions/saas | 2 | 524 | 14 |  |  |  |  |

## Method and limits

- Area score: 100 minus, per finding, severity amount (critical 25, high 12, medium 6, low 2) × (0.5 + 0.5 × share of pages affected). Content and AI readiness blend 70% Jev judgment with 30% rules. Performance blends 50% Lighthouse mobile with 50% crawl observations.
- Overall: weighted mean of scored areas; unscored areas are excluded, never zero.
- Impact: severity weight × (0.6 + 0.4 × reach) × (0.6 + 0.8 × highest Jev importance of affected pages), scaled to 100.
- Jev answers are decisive at confidence 0.80 (Choice, Score) or P(yes) at least 0.80 or at most 0.20 (Noul). Others are flagged to verify.
- Jev: model n/a, 0 requests, 0 input tokens, 0 failed, cost $0.0000.
- No Search Console, analytics, backlink or keyword data was used (run with --full for DataForSEO).
- Scores rank work; they do not predict rankings or traffic.

_Generated by jev-seo 0.1.1._
