# Digest: tellbear.com
Audited 2026-11-26T10:43:06+00:00. Pages fetched: 72; HTML pages: 72.
Overall 98 (A). Crawl and indexing 94, On-page 99, Content quality n/a, Links and architecture 100, Structured data and sharing 99, AI search readiness 100, Performance 100, Security and trust 100, Search visibility and authority n/a
Caps: none. Completeness: {'categories_scored': 7, 'categories_total': 9, 'jev': False, 'jev_pages_not_judged': 0, 'pagespeed': False, 'dataforseo': False}
PARTIAL AUDIT: Jev judgments unavailable, so content quality was not assessed; PageSpeed Insights unavailable, so performance used crawl timings only. Say so in the narrative.
Homepage: title='TellBear: Sales intelligence that uncovers buying signals'; h1=['See who’s ready to buy before your competitors do.']; meta='TellBear is a sales intelligence platform that uncovers buying signals and sales opportunities hidden in company data, with evidence for every signal.'

## Actions (id, priority, impact, effort, count, title, evidence, review flags)
- JEV-001 P2 impact 100 effort 1 [rule/crawl/medium] www and non-www both serve the site x1: www.tellbear.com answers without redirecting to the preferred host
  URLs: www.tellbear.com/
- JEV-002 P2 impact 61 effort 3 [rule/content/medium] Pages with very little main content x2: /contact: 81 words; /opt-out: 73 words
  URLs: /contact, /opt-out
- JEV-003 P3 impact 20 effort 1 [rule/onpage/low] Very short or very long titles x2: 70 chars; 68 chars
  URLs: /api, /mcp
- JEV-004 P3 impact 20 effort 1 [rule/structured/low] Structured data missing properties Google requires for rich results x1: SoftwareApplication on / lacks aggregateRating or review
  URLs: /

Robots: search bots {'Googlebot': True, 'Bingbot': True}; AI bots checked (10): {'GPTBot': True, 'OAI-SearchBot': True, 'ChatGPT-User': True, 'ClaudeBot': True, 'Claude-SearchBot': True, 'PerplexityBot': True, 'Google-Extended': True, 'Applebot-Extended': True, 'CCBot': True, 'Bytespider': True}

## No issue detected by rule
robots_missing, robots_blocks_site, sitemap_missing, sitemap_errors, sitemap_bad_urls, not_in_sitemap, http_errors, broken_internal_links, redirect_chains, links_to_redirects, noindex, canonical_missing, canonical_elsewhere, canonical_broken, soft_404, host_temporary_redirect, no_https, deep_pages, orphan_pages, js_dependent, title_missing, title_duplicate, multiple_titles, meta_missing, meta_duplicate, h1_missing, h1_multiple, heading_skips, lang_missing, viewport_missing, duplicate_content, images_alt, images_dimensions, no_structured_data, jsonld_errors, og_missing, hreflang_issues, ai_bots_blocked, llms_txt_missing, hsts_missing, security_headers, mixed_content, favicon_missing, slow_ttfb, heavy_html, generic_anchors, broken_external_links
